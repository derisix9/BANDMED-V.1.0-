# BANDMED — Sistema de Gestão Hospitalar

## Overview
Full-stack web application for hospital management (BANDMED). 100% offline system using SQLite local database.
Developed by Engº DFBANDE.

## Tech Stack
- **Frontend**: React + TypeScript + TanStack Query + Wouter + Shadcn UI + Tailwind CSS
- **Backend**: Node.js + Express + TypeScript
- **Database**: SQLite (better-sqlite3) — local file `hospital.db`
- **Auth**: Session-based (express-session) with bcrypt password hashing
- **Reports**: Excel export/import via xlsx package

## Default User
- **Username**: adolfozumbi
- **Password**: hmm
- **Role**: Administrador

## Features
- Splash screen with loading animation
- Login with session authentication
- Collapsible sidebar with 3 groups (Principal, Movimentações, Sistema)
- **Dashboard**: Stats overview, top products by stock, recent movements, active alerts
- **Products (Medicamentos)**: CRUD with form, pharmacological group, shelf assignment, stock tracking
- **Suppliers (Fornecedores)**: CRUD with contact info
- **Shelves (Prateleiras)**: CRUD with capacity/occupancy visualization, product viewer
- **Lots (Lotes)**: CRUD with expiry status (active/expiring/expired), FIFO exit logic
- **Movements (Entrada/Saída)**: CRUD with stock minimum enforcement, FIFO by expiry
- **Alerts**: Auto-generated alerts for low stock and expiring lots
- **Reports**: Excel export by section or all data
- **Database**: Info, export, import, seed, clear operations

## Business Rules
- Stock minimum check: exits blocked if stock would go below minimum
- FIFO for exits: earliest expiry date lots are used first
- Entry quantities counted only from movements (not lots) to avoid duplicates
- Alerts auto-generated on movement changes

## Project Structure
```
server/
  index.ts       — Express server + session setup + DB init
  db.ts          — SQLite connection + schema initialization
  storage.ts     — All CRUD operations
  routes.ts      — API route handlers

client/src/
  App.tsx        — Main routing + splash/login/layout
  hooks/use-auth.ts         — Auth hook
  components/app-sidebar.tsx — Sidebar navigation
  pages/
    splash.tsx     — Splash/loading screen
    login.tsx      — Login page
    dashboard.tsx  — Main dashboard
    products.tsx   — Medication management
    suppliers.tsx  — Supplier management
    shelves.tsx    — Shelf management
    lots.tsx       — Lot management
    movements.tsx  — Entry/exit movements
    alerts.tsx     — Alert notifications
    reports.tsx    — Excel reports
    database.tsx   — Database management
```

## Environment
- SESSION_SECRET: Used for express-session
- No DATABASE_URL needed (uses local SQLite)
