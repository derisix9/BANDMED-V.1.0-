import { db } from "./db";
import bcrypt from "bcryptjs";

export interface User {
  id: number;
  username: string;
  password: string;
  name: string;
  role: string;
  created_at: string;
}

export interface Supplier {
  id: number;
  name: string;
  contact_person?: string;
  email?: string;
  address?: string;
  phone?: string;
  created_at: string;
  updated_at: string;
}

export interface Shelf {
  id: number;
  name: string;
  capacity?: number;
  section?: string;
  product_count?: number;
  created_at: string;
  updated_at: string;
}

export interface Product {
  id: number;
  name: string;
  form?: string;
  pharmacological_group?: string;
  shelf_id?: number;
  shelf_name?: string;
  min_stock: number;
  price?: number;
  barcode?: string;
  total_entries?: number;
  total_exits?: number;
  current_stock?: number;
  created_at: string;
  updated_at: string;
}

export interface Lot {
  id: number;
  lot_number: string;
  expiry_date: string;
  quantity: number;
  supplier_id?: number;
  supplier_name?: string;
  product_id: number;
  product_name?: string;
  barcode?: string;
  status?: string;
  created_at: string;
  updated_at: string;
}

export interface Movement {
  id: number;
  product_id: number;
  product_name?: string;
  type: 'entrada' | 'saida';
  quantity: number;
  destination?: string;
  movement_date: string;
  price?: number;
  lot_id?: number;
  lot_number?: string;
  notes?: string;
  created_at: string;
  updated_at: string;
}

export interface Alert {
  id: number;
  type: 'validade' | 'stock' | 'lote' | 'outro';
  title: string;
  message: string;
  severity: 'info' | 'aviso' | 'critico';
  product_id?: number;
  lot_id?: number;
  is_read: number;
  created_at: string;
}

export interface DashboardStats {
  total_products: number;
  total_suppliers: number;
  total_shelves: number;
  total_lots: number;
  total_entries: number;
  total_exits: number;
  low_stock_count: number;
  expiring_soon_count: number;
  expired_count: number;
}

export const storage = {
  getUserByUsername(username: string): User | undefined {
    return db.prepare("SELECT * FROM users WHERE username = ?").get(username) as User | undefined;
  },

  validateUser(username: string, password: string): User | null {
    const user = db.prepare("SELECT * FROM users WHERE username = ?").get(username) as User | undefined;
    if (!user) return null;
    const valid = bcrypt.compareSync(password, user.password);
    return valid ? user : null;
  },

  getUsers(): Omit<User, 'password'>[] {
    return db.prepare("SELECT id, username, name, role, created_at FROM users").all() as Omit<User, 'password'>[];
  },

  getSuppliers(): Supplier[] {
    return db.prepare("SELECT * FROM suppliers ORDER BY name").all() as Supplier[];
  },

  getSupplier(id: number): Supplier | undefined {
    return db.prepare("SELECT * FROM suppliers WHERE id = ?").get(id) as Supplier | undefined;
  },

  createSupplier(data: Partial<Supplier>): Supplier {
    const result = db.prepare(
      "INSERT INTO suppliers (name, contact_person, email, address, phone) VALUES (?, ?, ?, ?, ?)"
    ).run(data.name, data.contact_person || null, data.email || null, data.address || null, data.phone || null);
    return this.getSupplier(result.lastInsertRowid as number)!;
  },

  updateSupplier(id: number, data: Partial<Supplier>): Supplier | undefined {
    db.prepare(
      "UPDATE suppliers SET name=?, contact_person=?, email=?, address=?, phone=?, updated_at=datetime('now') WHERE id=?"
    ).run(data.name, data.contact_person || null, data.email || null, data.address || null, data.phone || null, id);
    return this.getSupplier(id);
  },

  deleteSupplier(id: number): void {
    db.prepare("DELETE FROM suppliers WHERE id = ?").run(id);
  },

  getShelves(): Shelf[] {
    return db.prepare(`
      SELECT s.*, COUNT(p.id) as product_count
      FROM shelves s
      LEFT JOIN products p ON p.shelf_id = s.id
      GROUP BY s.id
      ORDER BY s.name
    `).all() as Shelf[];
  },

  getShelf(id: number): Shelf | undefined {
    return db.prepare(`
      SELECT s.*, COUNT(p.id) as product_count
      FROM shelves s
      LEFT JOIN products p ON p.shelf_id = s.id
      WHERE s.id = ?
      GROUP BY s.id
    `).get(id) as Shelf | undefined;
  },

  createShelf(data: Partial<Shelf>): Shelf {
    const result = db.prepare(
      "INSERT INTO shelves (name, capacity, section) VALUES (?, ?, ?)"
    ).run(data.name, data.capacity || null, data.section || null);
    return this.getShelf(result.lastInsertRowid as number)!;
  },

  updateShelf(id: number, data: Partial<Shelf>): Shelf | undefined {
    db.prepare(
      "UPDATE shelves SET name=?, capacity=?, section=?, updated_at=datetime('now') WHERE id=?"
    ).run(data.name, data.capacity || null, data.section || null, id);
    return this.getShelf(id);
  },

  deleteShelf(id: number): void {
    db.prepare("DELETE FROM shelves WHERE id = ?").run(id);
  },

  getShelfProducts(shelfId: number): Product[] {
    return db.prepare("SELECT * FROM products WHERE shelf_id = ? ORDER BY name").all(shelfId) as Product[];
  },

  getProducts(): Product[] {
    return db.prepare(`
      SELECT p.*,
        s.name as shelf_name,
        COALESCE(SUM(CASE WHEN m.type = 'entrada' THEN m.quantity ELSE 0 END), 0) as total_entries,
        COALESCE(SUM(CASE WHEN m.type = 'saida' THEN m.quantity ELSE 0 END), 0) as total_exits,
        COALESCE(SUM(CASE WHEN m.type = 'entrada' THEN m.quantity ELSE 0 END), 0) -
        COALESCE(SUM(CASE WHEN m.type = 'saida' THEN m.quantity ELSE 0 END), 0) as current_stock
      FROM products p
      LEFT JOIN shelves s ON s.id = p.shelf_id
      LEFT JOIN movements m ON m.product_id = p.id
      GROUP BY p.id
      ORDER BY p.name
    `).all() as Product[];
  },

  getProduct(id: number): Product | undefined {
    return db.prepare(`
      SELECT p.*,
        s.name as shelf_name,
        COALESCE(SUM(CASE WHEN m.type = 'entrada' THEN m.quantity ELSE 0 END), 0) as total_entries,
        COALESCE(SUM(CASE WHEN m.type = 'saida' THEN m.quantity ELSE 0 END), 0) as total_exits,
        COALESCE(SUM(CASE WHEN m.type = 'entrada' THEN m.quantity ELSE 0 END), 0) -
        COALESCE(SUM(CASE WHEN m.type = 'saida' THEN m.quantity ELSE 0 END), 0) as current_stock
      FROM products p
      LEFT JOIN shelves s ON s.id = p.shelf_id
      LEFT JOIN movements m ON m.product_id = p.id
      WHERE p.id = ?
      GROUP BY p.id
    `).get(id) as Product | undefined;
  },

  createProduct(data: Partial<Product>): Product {
    const result = db.prepare(
      "INSERT INTO products (name, form, pharmacological_group, shelf_id, min_stock, price, barcode) VALUES (?, ?, ?, ?, ?, ?, ?)"
    ).run(data.name, data.form || null, data.pharmacological_group || null, data.shelf_id || null, data.min_stock || 0, data.price || null, data.barcode || null);
    return this.getProduct(result.lastInsertRowid as number)!;
  },

  updateProduct(id: number, data: Partial<Product>): Product | undefined {
    db.prepare(
      "UPDATE products SET name=?, form=?, pharmacological_group=?, shelf_id=?, min_stock=?, price=?, barcode=?, updated_at=datetime('now') WHERE id=?"
    ).run(data.name, data.form || null, data.pharmacological_group || null, data.shelf_id || null, data.min_stock || 0, data.price || null, data.barcode || null, id);
    return this.getProduct(id);
  },

  deleteProduct(id: number): void {
    db.prepare("DELETE FROM products WHERE id = ?").run(id);
  },

  getLots(): Lot[] {
    const today = new Date().toISOString().split('T')[0];
    const soon = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
    return db.prepare(`
      SELECT l.*,
        p.name as product_name,
        s.name as supplier_name,
        CASE
          WHEN l.expiry_date < ? THEN 'vencido'
          WHEN l.expiry_date <= ? THEN 'a_vencer'
          ELSE 'ativo'
        END as status
      FROM lots l
      LEFT JOIN products p ON p.id = l.product_id
      LEFT JOIN suppliers s ON s.id = l.supplier_id
      ORDER BY l.expiry_date ASC
    `).all(today, soon) as Lot[];
  },

  getLot(id: number): Lot | undefined {
    const today = new Date().toISOString().split('T')[0];
    const soon = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
    return db.prepare(`
      SELECT l.*,
        p.name as product_name,
        s.name as supplier_name,
        CASE
          WHEN l.expiry_date < ? THEN 'vencido'
          WHEN l.expiry_date <= ? THEN 'a_vencer'
          ELSE 'ativo'
        END as status
      FROM lots l
      LEFT JOIN products p ON p.id = l.product_id
      LEFT JOIN suppliers s ON s.id = l.supplier_id
      WHERE l.id = ?
    `).get(today, soon, id) as Lot | undefined;
  },

  createLot(data: Partial<Lot>): Lot {
    const result = db.prepare(
      "INSERT INTO lots (lot_number, expiry_date, quantity, supplier_id, product_id, barcode) VALUES (?, ?, ?, ?, ?, ?)"
    ).run(data.lot_number, data.expiry_date, data.quantity || 0, data.supplier_id || null, data.product_id, data.barcode || null);
    return this.getLot(result.lastInsertRowid as number)!;
  },

  updateLot(id: number, data: Partial<Lot>): Lot | undefined {
    db.prepare(
      "UPDATE lots SET lot_number=?, expiry_date=?, quantity=?, supplier_id=?, product_id=?, barcode=?, updated_at=datetime('now') WHERE id=?"
    ).run(data.lot_number, data.expiry_date, data.quantity || 0, data.supplier_id || null, data.product_id, data.barcode || null, id);
    return this.getLot(id);
  },

  deleteLot(id: number): void {
    db.prepare("DELETE FROM lots WHERE id = ?").run(id);
  },

  getMovements(): Movement[] {
    return db.prepare(`
      SELECT m.*,
        p.name as product_name,
        l.lot_number as lot_number
      FROM movements m
      LEFT JOIN products p ON p.id = m.product_id
      LEFT JOIN lots l ON l.id = m.lot_id
      ORDER BY m.created_at DESC
    `).all() as Movement[];
  },

  getMovement(id: number): Movement | undefined {
    return db.prepare(`
      SELECT m.*,
        p.name as product_name,
        l.lot_number as lot_number
      FROM movements m
      LEFT JOIN products p ON p.id = m.product_id
      LEFT JOIN lots l ON l.id = m.lot_id
      WHERE m.id = ?
    `).get(id) as Movement | undefined;
  },

  createMovement(data: Partial<Movement>): { success: boolean; movement?: Movement; error?: string } {
    if (data.type === 'saida') {
      const product = this.getProduct(data.product_id!);
      if (!product) return { success: false, error: 'Produto não encontrado' };

      const currentStock = product.current_stock || 0;
      if (currentStock - (data.quantity || 0) < (product.min_stock || 0)) {
        return {
          success: false,
          error: `Stock insuficiente. Stock actual: ${currentStock}, Stock mínimo: ${product.min_stock}, Quantidade solicitada: ${data.quantity}`
        };
      }

      if (!data.lot_id) {
        const today = new Date().toISOString().split('T')[0];
        const lot = db.prepare(`
          SELECT * FROM lots
          WHERE product_id = ? AND expiry_date >= ? AND quantity > 0
          ORDER BY expiry_date ASC
          LIMIT 1
        `).get(data.product_id, today) as Lot | undefined;

        if (lot) {
          data.lot_id = lot.id;
        }
      }
    }

    const result = db.prepare(
      "INSERT INTO movements (product_id, type, quantity, destination, movement_date, price, lot_id, notes) VALUES (?, ?, ?, ?, ?, ?, ?, ?)"
    ).run(
      data.product_id,
      data.type,
      data.quantity,
      data.destination || null,
      data.movement_date || new Date().toISOString().split('T')[0],
      data.price || null,
      data.lot_id || null,
      data.notes || null
    );

    this.generateAlerts();
    return { success: true, movement: this.getMovement(result.lastInsertRowid as number)! };
  },

  updateMovement(id: number, data: Partial<Movement>): Movement | undefined {
    db.prepare(
      "UPDATE movements SET product_id=?, type=?, quantity=?, destination=?, movement_date=?, price=?, lot_id=?, notes=?, updated_at=datetime('now') WHERE id=?"
    ).run(
      data.product_id,
      data.type,
      data.quantity,
      data.destination || null,
      data.movement_date,
      data.price || null,
      data.lot_id || null,
      data.notes || null,
      id
    );
    this.generateAlerts();
    return this.getMovement(id);
  },

  deleteMovement(id: number): void {
    db.prepare("DELETE FROM movements WHERE id = ?").run(id);
    this.generateAlerts();
  },

  getAlerts(): Alert[] {
    return db.prepare(`
      SELECT a.*, p.name as product_name
      FROM alerts a
      LEFT JOIN products p ON p.id = a.product_id
      ORDER BY a.created_at DESC
    `).all() as Alert[];
  },

  markAlertRead(id: number): void {
    db.prepare("UPDATE alerts SET is_read = 1 WHERE id = ?").run(id);
  },

  markAllAlertsRead(): void {
    db.prepare("UPDATE alerts SET is_read = 1").run();
  },

  generateAlerts(): void {
    db.prepare("DELETE FROM alerts WHERE type IN ('validade', 'stock')").run();

    const today = new Date().toISOString().split('T')[0];
    const soon = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];

    const expiredLots = db.prepare(`
      SELECT l.*, p.name as product_name FROM lots l
      LEFT JOIN products p ON p.id = l.product_id
      WHERE l.expiry_date < ? AND l.quantity > 0
    `).all(today) as any[];

    for (const lot of expiredLots) {
      db.prepare(
        "INSERT INTO alerts (type, title, message, severity, product_id, lot_id) VALUES (?, ?, ?, ?, ?, ?)"
      ).run(
        'validade',
        `Lote Vencido: ${lot.product_name}`,
        `O lote ${lot.lot_number} do produto "${lot.product_name}" está vencido (validade: ${lot.expiry_date}).`,
        'critico',
        lot.product_id,
        lot.id
      );
    }

    const expiringLots = db.prepare(`
      SELECT l.*, p.name as product_name FROM lots l
      LEFT JOIN products p ON p.id = l.product_id
      WHERE l.expiry_date >= ? AND l.expiry_date <= ? AND l.quantity > 0
    `).all(today, soon) as any[];

    for (const lot of expiringLots) {
      db.prepare(
        "INSERT INTO alerts (type, title, message, severity, product_id, lot_id) VALUES (?, ?, ?, ?, ?, ?)"
      ).run(
        'validade',
        `Lote a Vencer: ${lot.product_name}`,
        `O lote ${lot.lot_number} do produto "${lot.product_name}" vence em ${lot.expiry_date}.`,
        'aviso',
        lot.product_id,
        lot.id
      );
    }

    const lowStockProducts = db.prepare(`
      SELECT p.*,
        COALESCE(SUM(CASE WHEN m.type = 'entrada' THEN m.quantity ELSE 0 END), 0) -
        COALESCE(SUM(CASE WHEN m.type = 'saida' THEN m.quantity ELSE 0 END), 0) as current_stock
      FROM products p
      LEFT JOIN movements m ON m.product_id = p.id
      GROUP BY p.id
      HAVING current_stock <= p.min_stock AND p.min_stock > 0
    `).all() as any[];

    for (const product of lowStockProducts) {
      db.prepare(
        "INSERT INTO alerts (type, title, message, severity, product_id) VALUES (?, ?, ?, ?, ?)"
      ).run(
        'stock',
        `Stock Mínimo: ${product.name}`,
        `O produto "${product.name}" atingiu o stock mínimo. Stock actual: ${product.current_stock}, Mínimo: ${product.min_stock}.`,
        product.current_stock <= 0 ? 'critico' : 'aviso',
        product.id
      );
    }
  },

  getDashboardStats(): DashboardStats {
    const today = new Date().toISOString().split('T')[0];
    const soon = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];

    const totalProducts = (db.prepare("SELECT COUNT(*) as count FROM products").get() as any).count;
    const totalSuppliers = (db.prepare("SELECT COUNT(*) as count FROM suppliers").get() as any).count;
    const totalShelves = (db.prepare("SELECT COUNT(*) as count FROM shelves").get() as any).count;
    const totalLots = (db.prepare("SELECT COUNT(*) as count FROM lots").get() as any).count;
    const totalEntries = (db.prepare("SELECT COALESCE(SUM(quantity), 0) as sum FROM movements WHERE type = 'entrada'").get() as any).sum;
    const totalExits = (db.prepare("SELECT COALESCE(SUM(quantity), 0) as sum FROM movements WHERE type = 'saida'").get() as any).sum;

    const lowStockCount = (db.prepare(`
      SELECT COUNT(*) as count FROM (
        SELECT p.id,
          COALESCE(SUM(CASE WHEN m.type = 'entrada' THEN m.quantity ELSE 0 END), 0) -
          COALESCE(SUM(CASE WHEN m.type = 'saida' THEN m.quantity ELSE 0 END), 0) as current_stock,
          p.min_stock
        FROM products p
        LEFT JOIN movements m ON m.product_id = p.id
        GROUP BY p.id
        HAVING current_stock <= p.min_stock AND p.min_stock > 0
      )
    `).get() as any).count;

    const expiringSoonCount = (db.prepare(
      "SELECT COUNT(*) as count FROM lots WHERE expiry_date >= ? AND expiry_date <= ?"
    ).get(today, soon) as any).count;

    const expiredCount = (db.prepare(
      "SELECT COUNT(*) as count FROM lots WHERE expiry_date < ?"
    ).get(today) as any).count;

    return {
      total_products: totalProducts,
      total_suppliers: totalSuppliers,
      total_shelves: totalShelves,
      total_lots: totalLots,
      total_entries: totalEntries,
      total_exits: totalExits,
      low_stock_count: lowStockCount,
      expiring_soon_count: expiringSoonCount,
      expired_count: expiredCount,
    };
  },

  getTopProductsByStock(): Product[] {
    return db.prepare(`
      SELECT p.name,
        COALESCE(SUM(CASE WHEN m.type = 'entrada' THEN m.quantity ELSE 0 END), 0) -
        COALESCE(SUM(CASE WHEN m.type = 'saida' THEN m.quantity ELSE 0 END), 0) as current_stock
      FROM products p
      LEFT JOIN movements m ON m.product_id = p.id
      GROUP BY p.id
      ORDER BY current_stock DESC
      LIMIT 10
    `).all() as Product[];
  },

  getRecentMovements(limit: number = 10): Movement[] {
    return db.prepare(`
      SELECT m.*,
        p.name as product_name,
        l.lot_number as lot_number
      FROM movements m
      LEFT JOIN products p ON p.id = m.product_id
      LEFT JOIN lots l ON l.id = m.lot_id
      ORDER BY m.created_at DESC
      LIMIT ?
    `).all(limit) as Movement[];
  },

  clearDatabase(): void {
    db.exec(`
      DELETE FROM alerts;
      DELETE FROM movements;
      DELETE FROM lots;
      DELETE FROM products;
      DELETE FROM shelves;
      DELETE FROM suppliers;
    `);
  },

  seedSampleData(): void {
    const existingProducts = db.prepare("SELECT COUNT(*) as count FROM products").get() as any;
    if (existingProducts.count > 0) return;

    const sup1 = this.createSupplier({ name: "Medimport Angola", contact_person: "Carlos Silva", email: "carlos@medimport.ao", phone: "+244 923 456 789", address: "Luanda, Angola" });
    const sup2 = this.createSupplier({ name: "FarmaDistrib", contact_person: "Ana Costa", email: "ana@farmadistrib.ao", phone: "+244 912 345 678" });

    const shelf1 = this.createShelf({ name: "Prateleira A1", capacity: 200, section: "Secção A" });
    const shelf2 = this.createShelf({ name: "Prateleira B1", capacity: 150, section: "Secção B" });
    const shelf3 = this.createShelf({ name: "Prateleira C1", capacity: 100, section: "Secção C" });

    const prod1 = this.createProduct({ name: "Paracetamol 500mg", form: "Comprimido", pharmacological_group: "Analgésico", shelf_id: shelf1.id, min_stock: 50, price: 500 });
    const prod2 = this.createProduct({ name: "Amoxicilina 250mg", form: "Cápsula", pharmacological_group: "Antibiótico", shelf_id: shelf1.id, min_stock: 30, price: 1200 });
    const prod3 = this.createProduct({ name: "Ibuprofeno 400mg", form: "Comprimido", pharmacological_group: "Anti-inflamatório", shelf_id: shelf2.id, min_stock: 20, price: 800 });
    const prod4 = this.createProduct({ name: "Metformina 500mg", form: "Comprimido", pharmacological_group: "Antidiabético", shelf_id: shelf2.id, min_stock: 25, price: 600 });
    const prod5 = this.createProduct({ name: "Soro Fisiológico 500ml", form: "Solução", pharmacological_group: "Solução de Infusão", shelf_id: shelf3.id, min_stock: 10, price: 1500 });

    const today = new Date();
    const future1 = new Date(today.getFullYear() + 2, today.getMonth(), today.getDate()).toISOString().split('T')[0];
    const future2 = new Date(today.getFullYear() + 1, today.getMonth() + 6, today.getDate()).toISOString().split('T')[0];
    const soon30 = new Date(today.getTime() + 25 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
    const expired = new Date(today.getFullYear() - 1, today.getMonth(), today.getDate()).toISOString().split('T')[0];

    this.createLot({ lot_number: "L001-2024", expiry_date: future1, quantity: 500, supplier_id: sup1.id, product_id: prod1.id });
    this.createLot({ lot_number: "L002-2024", expiry_date: future2, quantity: 200, supplier_id: sup1.id, product_id: prod2.id });
    this.createLot({ lot_number: "L003-2024", expiry_date: soon30, quantity: 100, supplier_id: sup2.id, product_id: prod3.id });
    this.createLot({ lot_number: "L004-2023", expiry_date: expired, quantity: 50, supplier_id: sup2.id, product_id: prod4.id });
    this.createLot({ lot_number: "L005-2024", expiry_date: future1, quantity: 80, supplier_id: sup1.id, product_id: prod5.id });

    const moveDate = new Date().toISOString().split('T')[0];
    db.prepare("INSERT INTO movements (product_id, type, quantity, destination, movement_date) VALUES (?, ?, ?, ?, ?)").run(prod1.id, 'entrada', 500, null, moveDate);
    db.prepare("INSERT INTO movements (product_id, type, quantity, destination, movement_date) VALUES (?, ?, ?, ?, ?)").run(prod2.id, 'entrada', 200, null, moveDate);
    db.prepare("INSERT INTO movements (product_id, type, quantity, destination, movement_date) VALUES (?, ?, ?, ?, ?)").run(prod3.id, 'entrada', 100, null, moveDate);
    db.prepare("INSERT INTO movements (product_id, type, quantity, destination, movement_date) VALUES (?, ?, ?, ?, ?)").run(prod4.id, 'entrada', 50, null, moveDate);
    db.prepare("INSERT INTO movements (product_id, type, quantity, destination, movement_date) VALUES (?, ?, ?, ?, ?)").run(prod5.id, 'entrada', 80, null, moveDate);
    db.prepare("INSERT INTO movements (product_id, type, quantity, destination, movement_date, notes) VALUES (?, ?, ?, ?, ?, ?)").run(prod1.id, 'saida', 50, 'Enfermaria A', moveDate, 'Distribuição semanal');
    db.prepare("INSERT INTO movements (product_id, type, quantity, destination, movement_date, notes) VALUES (?, ?, ?, ?, ?, ?)").run(prod2.id, 'saida', 30, 'Pediatria', moveDate, 'Uso hospitalar');

    this.generateAlerts();
  },

  exportAllData() {
    return {
      suppliers: this.getSuppliers(),
      shelves: this.getShelves(),
      products: this.getProducts(),
      lots: this.getLots(),
      movements: this.getMovements(),
    };
  },
};
