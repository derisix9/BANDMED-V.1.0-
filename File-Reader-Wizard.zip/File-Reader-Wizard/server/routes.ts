import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import * as XLSX from "xlsx";
import multer from "multer";

const upload = multer({ storage: multer.memoryStorage() });

declare module "express-session" {
  interface SessionData {
    userId?: number;
    username?: string;
    name?: string;
    role?: string;
  }
}

function requireAuth(req: any, res: any, next: any) {
  if (!req.session?.userId) {
    return res.status(401).json({ error: "Não autorizado" });
  }
  next();
}

export async function registerRoutes(httpServer: Server, app: Express): Promise<Server> {
  app.post("/api/auth/login", (req, res) => {
    const { username, password } = req.body;
    const user = storage.validateUser(username, password);
    if (!user) {
      return res.status(401).json({ error: "Utilizador ou senha inválidos" });
    }
    req.session!.userId = user.id;
    req.session!.username = user.username;
    req.session!.name = user.name;
    req.session!.role = user.role;
    res.json({ id: user.id, username: user.username, name: user.name, role: user.role });
  });

  app.post("/api/auth/logout", (req, res) => {
    req.session!.destroy(() => {});
    res.json({ success: true });
  });

  app.get("/api/auth/me", (req, res) => {
    if (!req.session?.userId) return res.json(null);
    res.json({
      id: req.session.userId,
      username: req.session.username,
      name: req.session.name,
      role: req.session.role,
    });
  });

  app.get("/api/dashboard/stats", requireAuth, (req, res) => {
    res.json(storage.getDashboardStats());
  });

  app.get("/api/dashboard/top-products", requireAuth, (req, res) => {
    res.json(storage.getTopProductsByStock());
  });

  app.get("/api/dashboard/recent-movements", requireAuth, (req, res) => {
    res.json(storage.getRecentMovements(10));
  });

  app.get("/api/suppliers", requireAuth, (req, res) => {
    res.json(storage.getSuppliers());
  });
  app.get("/api/suppliers/:id", requireAuth, (req, res) => {
    const s = storage.getSupplier(Number(req.params.id));
    if (!s) return res.status(404).json({ error: "Não encontrado" });
    res.json(s);
  });
  app.post("/api/suppliers", requireAuth, (req, res) => {
    if (!req.body.name) return res.status(400).json({ error: "Nome obrigatório" });
    res.status(201).json(storage.createSupplier(req.body));
  });
  app.put("/api/suppliers/:id", requireAuth, (req, res) => {
    const s = storage.updateSupplier(Number(req.params.id), req.body);
    if (!s) return res.status(404).json({ error: "Não encontrado" });
    res.json(s);
  });
  app.delete("/api/suppliers/:id", requireAuth, (req, res) => {
    storage.deleteSupplier(Number(req.params.id));
    res.status(204).end();
  });

  app.get("/api/shelves", requireAuth, (req, res) => {
    res.json(storage.getShelves());
  });
  app.get("/api/shelves/:id", requireAuth, (req, res) => {
    const s = storage.getShelf(Number(req.params.id));
    if (!s) return res.status(404).json({ error: "Não encontrado" });
    res.json(s);
  });
  app.get("/api/shelves/:id/products", requireAuth, (req, res) => {
    res.json(storage.getShelfProducts(Number(req.params.id)));
  });
  app.post("/api/shelves", requireAuth, (req, res) => {
    if (!req.body.name) return res.status(400).json({ error: "Nome obrigatório" });
    res.status(201).json(storage.createShelf(req.body));
  });
  app.put("/api/shelves/:id", requireAuth, (req, res) => {
    const s = storage.updateShelf(Number(req.params.id), req.body);
    if (!s) return res.status(404).json({ error: "Não encontrado" });
    res.json(s);
  });
  app.delete("/api/shelves/:id", requireAuth, (req, res) => {
    storage.deleteShelf(Number(req.params.id));
    res.status(204).end();
  });

  app.get("/api/products", requireAuth, (req, res) => {
    res.json(storage.getProducts());
  });
  app.get("/api/products/:id", requireAuth, (req, res) => {
    const p = storage.getProduct(Number(req.params.id));
    if (!p) return res.status(404).json({ error: "Não encontrado" });
    res.json(p);
  });
  app.post("/api/products", requireAuth, (req, res) => {
    if (!req.body.name) return res.status(400).json({ error: "Nome obrigatório" });
    res.status(201).json(storage.createProduct(req.body));
  });
  app.put("/api/products/:id", requireAuth, (req, res) => {
    const p = storage.updateProduct(Number(req.params.id), req.body);
    if (!p) return res.status(404).json({ error: "Não encontrado" });
    res.json(p);
  });
  app.delete("/api/products/:id", requireAuth, (req, res) => {
    storage.deleteProduct(Number(req.params.id));
    res.status(204).end();
  });

  app.get("/api/lots", requireAuth, (req, res) => {
    res.json(storage.getLots());
  });
  app.get("/api/lots/:id", requireAuth, (req, res) => {
    const l = storage.getLot(Number(req.params.id));
    if (!l) return res.status(404).json({ error: "Não encontrado" });
    res.json(l);
  });
  app.post("/api/lots", requireAuth, (req, res) => {
    if (!req.body.lot_number || !req.body.expiry_date || !req.body.product_id) {
      return res.status(400).json({ error: "Número de lote, validade e produto são obrigatórios" });
    }
    res.status(201).json(storage.createLot(req.body));
  });
  app.put("/api/lots/:id", requireAuth, (req, res) => {
    const l = storage.updateLot(Number(req.params.id), req.body);
    if (!l) return res.status(404).json({ error: "Não encontrado" });
    res.json(l);
  });
  app.delete("/api/lots/:id", requireAuth, (req, res) => {
    storage.deleteLot(Number(req.params.id));
    res.status(204).end();
  });

  app.get("/api/movements", requireAuth, (req, res) => {
    res.json(storage.getMovements());
  });
  app.get("/api/movements/:id", requireAuth, (req, res) => {
    const m = storage.getMovement(Number(req.params.id));
    if (!m) return res.status(404).json({ error: "Não encontrado" });
    res.json(m);
  });
  app.post("/api/movements", requireAuth, (req, res) => {
    if (!req.body.product_id || !req.body.type || !req.body.quantity) {
      return res.status(400).json({ error: "Produto, tipo e quantidade são obrigatórios" });
    }
    const result = storage.createMovement(req.body);
    if (!result.success) return res.status(400).json({ error: result.error });
    res.status(201).json(result.movement);
  });
  app.put("/api/movements/:id", requireAuth, (req, res) => {
    const m = storage.updateMovement(Number(req.params.id), req.body);
    if (!m) return res.status(404).json({ error: "Não encontrado" });
    res.json(m);
  });
  app.delete("/api/movements/:id", requireAuth, (req, res) => {
    storage.deleteMovement(Number(req.params.id));
    res.status(204).end();
  });

  app.get("/api/alerts", requireAuth, (req, res) => {
    res.json(storage.getAlerts());
  });
  app.put("/api/alerts/:id/read", requireAuth, (req, res) => {
    storage.markAlertRead(Number(req.params.id));
    res.json({ success: true });
  });
  app.put("/api/alerts/read-all", requireAuth, (req, res) => {
    storage.markAllAlertsRead();
    res.json({ success: true });
  });
  app.post("/api/alerts/generate", requireAuth, (req, res) => {
    storage.generateAlerts();
    res.json({ success: true });
  });

  app.get("/api/database/export", requireAuth, (req, res) => {
    const data = storage.exportAllData();
    const wb = XLSX.utils.book_new();

    const suppliersSheet = XLSX.utils.json_to_sheet(data.suppliers);
    XLSX.utils.book_append_sheet(wb, suppliersSheet, "Fornecedores");

    const shelvesSheet = XLSX.utils.json_to_sheet(data.shelves);
    XLSX.utils.book_append_sheet(wb, shelvesSheet, "Prateleiras");

    const productsSheet = XLSX.utils.json_to_sheet(data.products);
    XLSX.utils.book_append_sheet(wb, productsSheet, "Produtos");

    const lotsSheet = XLSX.utils.json_to_sheet(data.lots);
    XLSX.utils.book_append_sheet(wb, lotsSheet, "Lotes");

    const movementsSheet = XLSX.utils.json_to_sheet(data.movements);
    XLSX.utils.book_append_sheet(wb, movementsSheet, "Movimentações");

    const buf = XLSX.write(wb, { type: "buffer", bookType: "xlsx" });
    res.setHeader("Content-Disposition", `attachment; filename="hospital-db-${new Date().toISOString().split('T')[0]}.xlsx"`);
    res.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
    res.send(buf);
  });

  app.get("/api/reports/export", requireAuth, (req, res) => {
    const section = req.query.section as string;
    const data = storage.exportAllData();
    const wb = XLSX.utils.book_new();

    const addSheet = (sheetData: any[], name: string) => {
      if (sheetData.length > 0) {
        XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(sheetData), name);
      } else {
        XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet([{}]), name);
      }
    };

    if (!section || section === 'all') {
      addSheet(data.suppliers, "Fornecedores");
      addSheet(data.shelves, "Prateleiras");
      addSheet(data.products, "Produtos");
      addSheet(data.lots, "Lotes");
      addSheet(data.movements, "Movimentações");
    } else if (section === 'suppliers') addSheet(data.suppliers, "Fornecedores");
    else if (section === 'shelves') addSheet(data.shelves, "Prateleiras");
    else if (section === 'products') addSheet(data.products, "Produtos");
    else if (section === 'lots') addSheet(data.lots, "Lotes");
    else if (section === 'movements') addSheet(data.movements, "Movimentações");

    const buf = XLSX.write(wb, { type: "buffer", bookType: "xlsx" });
    res.setHeader("Content-Disposition", `attachment; filename="relatorio-${section || 'geral'}-${new Date().toISOString().split('T')[0]}.xlsx"`);
    res.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
    res.send(buf);
  });

  app.post("/api/database/import", requireAuth, upload.single("file"), (req, res) => {
    if (!req.file) return res.status(400).json({ error: "Ficheiro não fornecido" });
    try {
      const wb = XLSX.read(req.file.buffer, { type: "buffer" });
      res.json({ success: true, sheets: wb.SheetNames });
    } catch (err) {
      res.status(400).json({ error: "Ficheiro inválido" });
    }
  });

  app.post("/api/database/clear", requireAuth, (req, res) => {
    storage.clearDatabase();
    res.json({ success: true });
  });

  app.post("/api/database/seed", requireAuth, (req, res) => {
    storage.seedSampleData();
    res.json({ success: true });
  });

  app.get("/api/database/info", requireAuth, (req, res) => {
    const stats = storage.getDashboardStats();
    const fs = require("fs");
    const path = require("path");
    const dbPath = path.join(process.cwd(), "hospital.db");
    let dbSize = 0;
    try {
      const stat = fs.statSync(dbPath);
      dbSize = stat.size;
    } catch {}

    res.json({
      path: dbPath,
      size: dbSize,
      size_mb: (dbSize / 1024 / 1024).toFixed(2),
      stats,
    });
  });

  return httpServer;
}
