import { useState, useEffect } from "react";
import { Switch, Route } from "wouter";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { AppSidebar } from "@/components/app-sidebar";
import { useAuth } from "@/hooks/use-auth";
import { Bell, Sun, Moon } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";

import Splash from "@/pages/splash";
import Login from "@/pages/login";
import Dashboard from "@/pages/dashboard";
import Products from "@/pages/products";
import Suppliers from "@/pages/suppliers";
import Shelves from "@/pages/shelves";
import Lots from "@/pages/lots";
import Movements from "@/pages/movements";
import Alerts from "@/pages/alerts";
import Reports from "@/pages/reports";
import DatabasePage from "@/pages/database";
import NotFound from "@/pages/not-found";

function ThemeToggle() {
  const [dark, setDark] = useState(() => document.documentElement.classList.contains("dark"));
  const toggle = () => {
    const next = !dark;
    setDark(next);
    document.documentElement.classList.toggle("dark", next);
    localStorage.setItem("theme", next ? "dark" : "light");
  };
  return (
    <Button size="icon" variant="ghost" onClick={toggle} className="w-8 h-8">
      {dark ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
    </Button>
  );
}

function AlertBell() {
  const { data: alerts = [] } = useQuery<any[]>({ queryKey: ["/api/alerts"] });
  const unread = (alerts as any[]).filter(a => !a.is_read).length;
  return (
    <Link href="/alerts">
      <Button size="icon" variant="ghost" className="w-8 h-8 relative">
        <Bell className="w-4 h-4" />
        {unread > 0 && (
          <span className="absolute -top-0.5 -right-0.5 min-w-4 h-4 rounded-full text-xs font-bold flex items-center justify-center px-0.5"
            style={{ background: "hsl(0, 72%, 51%)", color: "white", fontSize: "10px" }}>
            {unread > 99 ? "99+" : unread}
          </span>
        )}
      </Button>
    </Link>
  );
}

function AppLayout() {
  const sidebarStyle = {
    "--sidebar-width": "16rem",
    "--sidebar-width-icon": "3rem",
  };

  return (
    <SidebarProvider style={sidebarStyle as React.CSSProperties}>
      <div className="flex h-screen w-full overflow-hidden">
        <AppSidebar />
        <div className="flex flex-col flex-1 min-w-0 overflow-hidden">
          <header className="flex items-center justify-between px-4 py-2 border-b border-border bg-card/80 backdrop-blur-sm flex-shrink-0">
            <SidebarTrigger data-testid="button-sidebar-toggle" className="w-8 h-8" />
            <div className="flex items-center gap-1">
              <AlertBell />
              <ThemeToggle />
            </div>
          </header>
          <main className="flex-1 overflow-hidden">
            <Switch>
              <Route path="/" component={Dashboard} />
              <Route path="/products" component={Products} />
              <Route path="/suppliers" component={Suppliers} />
              <Route path="/shelves" component={Shelves} />
              <Route path="/lots" component={Lots} />
              <Route path="/movements" component={Movements} />
              <Route path="/alerts" component={Alerts} />
              <Route path="/reports" component={Reports} />
              <Route path="/database" component={DatabasePage} />
              <Route component={NotFound} />
            </Switch>
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
}

function AuthGate() {
  const { user, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="fixed inset-0 flex items-center justify-center"
        style={{ background: "linear-gradient(135deg, hsl(215, 42%, 14%) 0%, hsl(205, 60%, 22%) 50%, hsl(215, 42%, 10%) 100%)" }}>
        <div className="w-8 h-8 rounded-full border-2 border-white/20 border-t-white spin-slow" />
      </div>
    );
  }

  if (!user) return <Login />;
  return <AppLayout />;
}

function Root() {
  const [showSplash, setShowSplash] = useState(true);

  useEffect(() => {
    const saved = localStorage.getItem("theme");
    if (saved === "dark" || (!saved && window.matchMedia("(prefers-color-scheme: dark)").matches)) {
      document.documentElement.classList.add("dark");
    }
  }, []);

  if (showSplash) {
    return <Splash onFinish={() => setShowSplash(false)} />;
  }

  return <AuthGate />;
}

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Root />
      </TooltipProvider>
    </QueryClientProvider>
  );
}
