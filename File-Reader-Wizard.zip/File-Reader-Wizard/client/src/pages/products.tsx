import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Package, Plus, Search, Edit, Trash2, AlertTriangle,
  TrendingUp, TrendingDown, FlaskConical, Pill, Archive
} from "lucide-react";

const DRUG_FORMS = [
  "Comprimido", "Cápsula", "Xarope", "Solução", "Injeção", "Pomada", "Creme",
  "Gel", "Supositório", "Gotas", "Spray", "Inalador", "Patch", "Ampola", "Outro"
];

const PHARMACOLOGICAL_GROUPS = [
  "Analgésico", "Antibiótico", "Anti-inflamatório", "Antidiabético", "Anti-hipertensivo",
  "Antiviral", "Antifúngico", "Antiparasitário", "Vitamina/Suplemento", "Vacina",
  "Solução de Infusão", "Antialérgico", "Antidepressivo", "Ansiolítico", "Diurético",
  "Anticoagulante", "Broncodilatador", "Antieméticos", "Laxante", "Outro"
];

const STATUS_COLORS: Record<string, string> = {
  ok: "badge-active",
  warning: "badge-warning",
  critical: "badge-critical",
};

function getStockStatus(product: any) {
  const stock = product.current_stock || 0;
  if (stock <= 0) return { label: "Sem Stock", cls: "badge-critical" };
  if (stock <= product.min_stock) return { label: "Stock Mínimo", cls: "badge-warning" };
  return { label: "Normal", cls: "badge-active" };
}

const emptyForm = {
  name: "", form: "", pharmacological_group: "", shelf_id: "", min_stock: "", price: "", barcode: ""
};

export default function Products() {
  const { toast } = useToast();
  const [search, setSearch] = useState("");
  const [isOpen, setIsOpen] = useState(false);
  const [editItem, setEditItem] = useState<any>(null);
  const [deleteId, setDeleteId] = useState<number | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [customForm, setCustomForm] = useState("");
  const [customGroup, setCustomGroup] = useState("");

  const { data: products = [], isLoading } = useQuery<any[]>({ queryKey: ["/api/products"] });
  const { data: shelves = [] } = useQuery<any[]>({ queryKey: ["/api/shelves"] });

  const saveMutation = useMutation({
    mutationFn: async (data: any) => {
      if (editItem) {
        return (await apiRequest("PUT", `/api/products/${editItem.id}`, data)).json();
      }
      return (await apiRequest("POST", "/api/products", data)).json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      toast({ title: editItem ? "Produto actualizado" : "Produto cadastrado", description: "Operação realizada com sucesso." });
      setIsOpen(false);
    },
    onError: (e: any) => toast({ title: "Erro", description: e.message, variant: "destructive" }),
  });

  const deleteMutation = useMutation({
    mutationFn: (id: number) => apiRequest("DELETE", `/api/products/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      toast({ title: "Produto eliminado" });
      setDeleteId(null);
    },
    onError: (e: any) => toast({ title: "Erro", description: e.message, variant: "destructive" }),
  });

  const openCreate = () => {
    setEditItem(null);
    setForm(emptyForm);
    setCustomForm(""); setCustomGroup("");
    setIsOpen(true);
  };

  const openEdit = (item: any) => {
    setEditItem(item);
    setForm({
      name: item.name || "",
      form: item.form || "",
      pharmacological_group: item.pharmacological_group || "",
      shelf_id: item.shelf_id ? String(item.shelf_id) : "",
      min_stock: item.min_stock != null ? String(item.min_stock) : "",
      price: item.price != null ? String(item.price) : "",
      barcode: item.barcode || "",
    });
    setCustomForm(DRUG_FORMS.includes(item.form) ? "" : (item.form || ""));
    setCustomGroup(PHARMACOLOGICAL_GROUPS.includes(item.pharmacological_group) ? "" : (item.pharmacological_group || ""));
    setIsOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name.trim()) {
      toast({ title: "Nome obrigatório", variant: "destructive" }); return;
    }
    saveMutation.mutate({
      name: form.name.trim(),
      form: form.form === "Outro" ? customForm : (form.form || null),
      pharmacological_group: form.pharmacological_group === "Outro" ? customGroup : (form.pharmacological_group || null),
      shelf_id: form.shelf_id ? Number(form.shelf_id) : null,
      min_stock: form.min_stock ? Number(form.min_stock) : 0,
      price: form.price ? Number(form.price) : null,
      barcode: form.barcode || null,
    });
  };

  const filtered = (products as any[]).filter(p =>
    p.name?.toLowerCase().includes(search.toLowerCase()) ||
    p.form?.toLowerCase().includes(search.toLowerCase()) ||
    p.pharmacological_group?.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="flex flex-col h-full overflow-y-auto">
      <div className="flex-shrink-0 px-6 py-4 border-b border-border bg-card/50">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <Package className="w-5 h-5 text-primary" />
            <h1 className="text-xl font-bold">Medicamentos</h1>
            <span className="badge-info px-2 py-0.5 rounded-full text-xs font-medium">{filtered.length}</span>
          </div>
          <Button onClick={openCreate} data-testid="button-add-product" className="gap-2">
            <Plus className="w-4 h-4" /> Novo Medicamento
          </Button>
        </div>
        <div className="mt-3 relative max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input placeholder="Pesquisar medicamentos..." className="pl-9" value={search}
            onChange={e => setSearch(e.target.value)} data-testid="input-search-products" />
        </div>
      </div>

      <div className="flex-1 p-6">
        {isLoading ? (
          <div className="flex items-center justify-center h-40">
            <div className="btn-spinner w-8 h-8 border-2 border-primary/30 border-t-primary" />
          </div>
        ) : filtered.length === 0 ? (
          <Card>
            <CardContent className="flex flex-col items-center justify-center py-12 gap-3">
              <Package className="w-12 h-12 text-muted-foreground/30" />
              <p className="text-muted-foreground font-medium">Nenhum medicamento encontrado</p>
              <Button onClick={openCreate} variant="outline" className="gap-2">
                <Plus className="w-4 h-4" /> Adicionar primeiro medicamento
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="rounded-lg border border-border overflow-hidden bg-card">
            <div className="overflow-x-auto">
              <table className="data-table">
                <thead className="bg-muted/50 border-b border-border">
                  <tr>
                    <th className="text-left data-table">Nome</th>
                    <th className="text-left data-table hidden sm:table-cell">Forma</th>
                    <th className="text-left data-table hidden md:table-cell">Grupo Farmacológico</th>
                    <th className="text-left data-table hidden lg:table-cell">Prateleira</th>
                    <th className="text-center data-table">Entradas</th>
                    <th className="text-center data-table">Saídas</th>
                    <th className="text-center data-table">Stock</th>
                    <th className="text-center data-table">Status</th>
                    <th className="text-left data-table hidden xl:table-cell">Preço</th>
                    <th className="text-center data-table">Ações</th>
                  </tr>
                </thead>
                <tbody>
                  {filtered.map((p: any) => {
                    const status = getStockStatus(p);
                    return (
                      <tr key={p.id} className="border-b border-border last:border-0 hover:bg-muted/30 transition-colors">
                        <td className="data-table">
                          <div className="flex items-center gap-2">
                            <div className="w-7 h-7 rounded-lg flex items-center justify-center flex-shrink-0"
                              style={{ background: "hsl(205, 75%, 90%)" }}>
                              <Pill className="w-3.5 h-3.5" style={{ color: "hsl(205, 75%, 35%)" }} />
                            </div>
                            <span className="font-medium text-sm text-foreground">{p.name}</span>
                          </div>
                        </td>
                        <td className="data-table hidden sm:table-cell">
                          <span className="text-sm text-muted-foreground">{p.form || "—"}</span>
                        </td>
                        <td className="data-table hidden md:table-cell">
                          {p.pharmacological_group ? (
                            <span className="text-xs badge-info px-2 py-0.5 rounded-full font-medium">{p.pharmacological_group}</span>
                          ) : <span className="text-sm text-muted-foreground">—</span>}
                        </td>
                        <td className="data-table hidden lg:table-cell">
                          <div className="flex items-center gap-1 text-sm text-muted-foreground">
                            {p.shelf_name ? (<><Archive className="w-3 h-3" />{p.shelf_name}</>) : "—"}
                          </div>
                        </td>
                        <td className="data-table text-center">
                          <span className="inline-flex items-center gap-1 text-sm font-semibold" style={{ color: "hsl(142, 72%, 35%)" }}>
                            <TrendingUp className="w-3 h-3" />{p.total_entries || 0}
                          </span>
                        </td>
                        <td className="data-table text-center">
                          <span className="inline-flex items-center gap-1 text-sm font-semibold" style={{ color: "hsl(0, 72%, 51%)" }}>
                            <TrendingDown className="w-3 h-3" />{p.total_exits || 0}
                          </span>
                        </td>
                        <td className="data-table text-center">
                          <span className="text-sm font-bold text-foreground">{p.current_stock || 0}</span>
                        </td>
                        <td className="data-table text-center">
                          <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${status.cls}`}>
                            {status.label}
                          </span>
                        </td>
                        <td className="data-table hidden xl:table-cell">
                          <span className="text-sm text-muted-foreground">
                            {p.price != null ? `${Number(p.price).toLocaleString('pt-AO')} AOA` : "—"}
                          </span>
                        </td>
                        <td className="data-table text-center">
                          <div className="flex items-center justify-center gap-1">
                            <Button size="icon" variant="ghost" onClick={() => openEdit(p)}
                              data-testid={`button-edit-product-${p.id}`} className="w-8 h-8">
                              <Edit className="w-3.5 h-3.5" />
                            </Button>
                            <Button size="icon" variant="ghost" onClick={() => setDeleteId(p.id)}
                              data-testid={`button-delete-product-${p.id}`}
                              className="w-8 h-8 text-destructive hover:text-destructive">
                              <Trash2 className="w-3.5 h-3.5" />
                            </Button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>

      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Package className="w-5 h-5 text-primary" />
              {editItem ? "Editar Medicamento" : "Novo Medicamento"}
            </DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4 py-2">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="sm:col-span-2 space-y-2">
                <Label className="flex items-center gap-1.5"><Package className="w-3.5 h-3.5" />Nome *</Label>
                <Input placeholder="Nome do medicamento" value={form.name}
                  onChange={e => setForm({ ...form, name: e.target.value })} data-testid="input-product-name" />
              </div>
              <div className="space-y-2">
                <Label className="flex items-center gap-1.5"><Pill className="w-3.5 h-3.5" />Forma Farmacêutica</Label>
                <Select value={form.form} onValueChange={v => setForm({ ...form, form: v })}>
                  <SelectTrigger data-testid="select-product-form"><SelectValue placeholder="Selecionar forma" /></SelectTrigger>
                  <SelectContent>
                    {DRUG_FORMS.map(f => <SelectItem key={f} value={f}>{f}</SelectItem>)}
                  </SelectContent>
                </Select>
                {form.form === "Outro" && (
                  <Input placeholder="Especifique a forma" value={customForm}
                    onChange={e => setCustomForm(e.target.value)} className="mt-1" />
                )}
              </div>
              <div className="space-y-2">
                <Label className="flex items-center gap-1.5"><FlaskConical className="w-3.5 h-3.5" />Grupo Farmacológico</Label>
                <Select value={form.pharmacological_group} onValueChange={v => setForm({ ...form, pharmacological_group: v })}>
                  <SelectTrigger><SelectValue placeholder="Selecionar grupo" /></SelectTrigger>
                  <SelectContent>
                    {PHARMACOLOGICAL_GROUPS.map(g => <SelectItem key={g} value={g}>{g}</SelectItem>)}
                  </SelectContent>
                </Select>
                {form.pharmacological_group === "Outro" && (
                  <Input placeholder="Especifique o grupo" value={customGroup}
                    onChange={e => setCustomGroup(e.target.value)} className="mt-1" />
                )}
              </div>
              <div className="space-y-2">
                <Label className="flex items-center gap-1.5"><Archive className="w-3.5 h-3.5" />Prateleira</Label>
                <Select value={form.shelf_id} onValueChange={v => setForm({ ...form, shelf_id: v })}>
                  <SelectTrigger><SelectValue placeholder="Selecionar prateleira" /></SelectTrigger>
                  <SelectContent>
                    {(shelves as any[]).map((s: any) => (
                      <SelectItem key={s.id} value={String(s.id)}>{s.name} {s.section ? `(${s.section})` : ""}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label className="flex items-center gap-1.5"><AlertTriangle className="w-3.5 h-3.5" />Stock Mínimo</Label>
                <Input type="number" min="0" placeholder="0" value={form.min_stock}
                  onChange={e => setForm({ ...form, min_stock: e.target.value })} />
              </div>
              <div className="space-y-2">
                <Label>Preço (AOA)</Label>
                <Input type="number" min="0" step="0.01" placeholder="0.00" value={form.price}
                  onChange={e => setForm({ ...form, price: e.target.value })} />
              </div>
              <div className="space-y-2">
                <Label>Código de Barras</Label>
                <Input placeholder="Opcional" value={form.barcode}
                  onChange={e => setForm({ ...form, barcode: e.target.value })} />
              </div>
            </div>
            <DialogFooter className="gap-2 pt-2">
              <Button type="button" variant="outline" onClick={() => setIsOpen(false)}>Cancelar</Button>
              <Button type="submit" disabled={saveMutation.isPending}>
                {saveMutation.isPending ? <span className="flex items-center gap-2"><span className="btn-spinner" />A guardar...</span>
                  : (editItem ? "Actualizar" : "Cadastrar")}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <AlertDialog open={deleteId !== null} onOpenChange={open => !open && setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Eliminar Medicamento?</AlertDialogTitle>
            <AlertDialogDescription>
              Esta acção é irreversível. Todos os lotes e movimentações associados serão eliminados.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={() => deleteId && deleteMutation.mutate(deleteId)}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              {deleteMutation.isPending ? <span className="flex items-center gap-2"><span className="btn-spinner" />A eliminar...</span> : "Eliminar"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
