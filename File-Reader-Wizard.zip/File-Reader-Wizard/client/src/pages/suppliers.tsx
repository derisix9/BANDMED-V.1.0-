import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Card, CardContent } from "@/components/ui/card";
import { Building2, Plus, Search, Edit, Trash2, Mail, Phone, MapPin, User } from "lucide-react";

const emptyForm = { name: "", contact_person: "", email: "", address: "", phone: "" };

export default function Suppliers() {
  const { toast } = useToast();
  const [search, setSearch] = useState("");
  const [isOpen, setIsOpen] = useState(false);
  const [editItem, setEditItem] = useState<any>(null);
  const [deleteId, setDeleteId] = useState<number | null>(null);
  const [form, setForm] = useState(emptyForm);

  const { data: suppliers = [], isLoading } = useQuery<any[]>({ queryKey: ["/api/suppliers"] });

  const saveMutation = useMutation({
    mutationFn: async (data: any) => {
      if (editItem) return (await apiRequest("PUT", `/api/suppliers/${editItem.id}`, data)).json();
      return (await apiRequest("POST", "/api/suppliers", data)).json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/suppliers"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      toast({ title: editItem ? "Fornecedor actualizado" : "Fornecedor cadastrado" });
      setIsOpen(false);
    },
    onError: (e: any) => toast({ title: "Erro", description: e.message, variant: "destructive" }),
  });

  const deleteMutation = useMutation({
    mutationFn: (id: number) => apiRequest("DELETE", `/api/suppliers/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/suppliers"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      toast({ title: "Fornecedor eliminado" });
      setDeleteId(null);
    },
    onError: (e: any) => toast({ title: "Erro", description: e.message, variant: "destructive" }),
  });

  const openCreate = () => {
    setEditItem(null);
    setForm(emptyForm);
    setIsOpen(true);
  };

  const openEdit = (item: any) => {
    setEditItem(item);
    setForm({ name: item.name || "", contact_person: item.contact_person || "", email: item.email || "", address: item.address || "", phone: item.phone || "" });
    setIsOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name.trim()) { toast({ title: "Nome obrigatório", variant: "destructive" }); return; }
    saveMutation.mutate({ name: form.name.trim(), contact_person: form.contact_person || null, email: form.email || null, address: form.address || null, phone: form.phone || null });
  };

  const filtered = (suppliers as any[]).filter(s =>
    s.name?.toLowerCase().includes(search.toLowerCase()) ||
    s.contact_person?.toLowerCase().includes(search.toLowerCase()) ||
    s.email?.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="flex flex-col h-full overflow-y-auto">
      <div className="flex-shrink-0 px-6 py-4 border-b border-border bg-card/50">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <Building2 className="w-5 h-5 text-primary" />
            <h1 className="text-xl font-bold">Fornecedores</h1>
            <span className="badge-info px-2 py-0.5 rounded-full text-xs font-medium">{filtered.length}</span>
          </div>
          <Button onClick={openCreate} className="gap-2" data-testid="button-add-supplier">
            <Plus className="w-4 h-4" /> Novo Fornecedor
          </Button>
        </div>
        <div className="mt-3 relative max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input placeholder="Pesquisar fornecedores..." className="pl-9" value={search}
            onChange={e => setSearch(e.target.value)} />
        </div>
      </div>

      <div className="flex-1 p-6">
        {isLoading ? (
          <div className="flex items-center justify-center h-40">
            <div className="btn-spinner w-8 h-8 border-2 border-primary/30 border-t-primary" />
          </div>
        ) : filtered.length === 0 ? (
          <Card>
            <CardContent className="flex flex-col items-center justify-center py-12 gap-3">
              <Building2 className="w-12 h-12 text-muted-foreground/30" />
              <p className="text-muted-foreground font-medium">Nenhum fornecedor encontrado</p>
              <Button onClick={openCreate} variant="outline" className="gap-2">
                <Plus className="w-4 h-4" /> Adicionar primeiro fornecedor
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="rounded-lg border border-border overflow-hidden bg-card">
            <div className="overflow-x-auto">
              <table className="data-table">
                <thead className="bg-muted/50 border-b border-border">
                  <tr>
                    <th className="text-left data-table">Nome</th>
                    <th className="text-left data-table hidden sm:table-cell">Contacto</th>
                    <th className="text-left data-table hidden md:table-cell">Email</th>
                    <th className="text-left data-table hidden lg:table-cell">Telefone</th>
                    <th className="text-left data-table hidden xl:table-cell">Endereço</th>
                    <th className="text-center data-table">Ações</th>
                  </tr>
                </thead>
                <tbody>
                  {filtered.map((s: any) => (
                    <tr key={s.id} className="border-b border-border last:border-0 hover:bg-muted/30 transition-colors">
                      <td className="data-table">
                        <div className="flex items-center gap-2">
                          <div className="w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0"
                            style={{ background: "hsl(205, 75%, 90%)" }}>
                            <Building2 className="w-4 h-4" style={{ color: "hsl(205, 75%, 35%)" }} />
                          </div>
                          <span className="font-medium text-sm text-foreground">{s.name}</span>
                        </div>
                      </td>
                      <td className="data-table hidden sm:table-cell">
                        <div className="flex items-center gap-1 text-sm text-muted-foreground">
                          <User className="w-3 h-3" />{s.contact_person || "—"}
                        </div>
                      </td>
                      <td className="data-table hidden md:table-cell">
                        {s.email ? (
                          <a href={`mailto:${s.email}`} className="flex items-center gap-1 text-sm text-primary hover:underline">
                            <Mail className="w-3 h-3" />{s.email}
                          </a>
                        ) : <span className="text-muted-foreground text-sm">—</span>}
                      </td>
                      <td className="data-table hidden lg:table-cell">
                        <div className="flex items-center gap-1 text-sm text-muted-foreground">
                          <Phone className="w-3 h-3" />{s.phone || "—"}
                        </div>
                      </td>
                      <td className="data-table hidden xl:table-cell">
                        <div className="flex items-center gap-1 text-sm text-muted-foreground">
                          <MapPin className="w-3 h-3" />{s.address || "—"}
                        </div>
                      </td>
                      <td className="data-table text-center">
                        <div className="flex items-center justify-center gap-1">
                          <Button size="icon" variant="ghost" onClick={() => openEdit(s)} className="w-8 h-8">
                            <Edit className="w-3.5 h-3.5" />
                          </Button>
                          <Button size="icon" variant="ghost" onClick={() => setDeleteId(s.id)}
                            className="w-8 h-8 text-destructive hover:text-destructive">
                            <Trash2 className="w-3.5 h-3.5" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>

      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Building2 className="w-5 h-5 text-primary" />
              {editItem ? "Editar Fornecedor" : "Novo Fornecedor"}
            </DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4 py-2">
            <div className="space-y-2">
              <Label className="flex items-center gap-1.5"><Building2 className="w-3.5 h-3.5" />Nome *</Label>
              <Input placeholder="Nome do fornecedor" value={form.name}
                onChange={e => setForm({ ...form, name: e.target.value })} data-testid="input-supplier-name" />
            </div>
            <div className="space-y-2">
              <Label className="flex items-center gap-1.5"><User className="w-3.5 h-3.5" />Pessoa de Contacto</Label>
              <Input placeholder="Nome do responsável" value={form.contact_person}
                onChange={e => setForm({ ...form, contact_person: e.target.value })} />
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="flex items-center gap-1.5"><Mail className="w-3.5 h-3.5" />Email</Label>
                <Input type="email" placeholder="email@exemplo.com" value={form.email}
                  onChange={e => setForm({ ...form, email: e.target.value })} />
              </div>
              <div className="space-y-2">
                <Label className="flex items-center gap-1.5"><Phone className="w-3.5 h-3.5" />Telefone</Label>
                <Input placeholder="+244 9XX XXX XXX" value={form.phone}
                  onChange={e => setForm({ ...form, phone: e.target.value })} />
              </div>
            </div>
            <div className="space-y-2">
              <Label className="flex items-center gap-1.5"><MapPin className="w-3.5 h-3.5" />Endereço</Label>
              <Input placeholder="Endereço completo" value={form.address}
                onChange={e => setForm({ ...form, address: e.target.value })} />
            </div>
            <DialogFooter className="gap-2 pt-2">
              <Button type="button" variant="outline" onClick={() => setIsOpen(false)}>Cancelar</Button>
              <Button type="submit" disabled={saveMutation.isPending}>
                {saveMutation.isPending ? <span className="flex items-center gap-2"><span className="btn-spinner" />A guardar...</span>
                  : (editItem ? "Actualizar" : "Cadastrar")}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <AlertDialog open={deleteId !== null} onOpenChange={open => !open && setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Eliminar Fornecedor?</AlertDialogTitle>
            <AlertDialogDescription>Esta acção é irreversível.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={() => deleteId && deleteMutation.mutate(deleteId)}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              {deleteMutation.isPending ? <span className="flex items-center gap-2"><span className="btn-spinner" />A eliminar...</span> : "Eliminar"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
