import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { FileText, Download, Package, Building2, Archive, Layers, ArrowLeftRight, Globe } from "lucide-react";

const SECTIONS = [
  { value: "all", label: "Relatório Geral (Tudo)", icon: Globe, description: "Exporta todos os dados do sistema" },
  { value: "products", label: "Medicamentos", icon: Package, description: "Lista de todos os medicamentos cadastrados" },
  { value: "suppliers", label: "Fornecedores", icon: Building2, description: "Lista de todos os fornecedores" },
  { value: "shelves", label: "Prateleiras", icon: Archive, description: "Lista de todas as prateleiras" },
  { value: "lots", label: "Lotes", icon: Layers, description: "Todos os lotes registados" },
  { value: "movements", label: "Movimentações", icon: ArrowLeftRight, description: "Todas as entradas e saídas" },
];

export default function Reports() {
  const { toast } = useToast();
  const [section, setSection] = useState("all");

  const exportMutation = useMutation({
    mutationFn: async (sec: string) => {
      const res = await fetch(`/api/reports/export?section=${sec}`, { credentials: "include" });
      if (!res.ok) throw new Error("Erro ao exportar");
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `relatorio-${sec}-${new Date().toISOString().split('T')[0]}.xlsx`;
      a.click();
      URL.revokeObjectURL(url);
    },
    onSuccess: () => toast({ title: "Relatório exportado", description: "O ficheiro Excel foi transferido." }),
    onError: (e: any) => toast({ title: "Erro", description: e.message, variant: "destructive" }),
  });

  const selectedSection = SECTIONS.find(s => s.value === section);

  return (
    <div className="flex flex-col h-full overflow-y-auto">
      <div className="flex-shrink-0 px-6 py-4 border-b border-border bg-card/50">
        <div className="flex items-center gap-2">
          <FileText className="w-5 h-5 text-primary" />
          <h1 className="text-xl font-bold">Relatórios</h1>
        </div>
        <p className="text-sm text-muted-foreground mt-1">Exporte dados do sistema em formato Excel (.xlsx)</p>
      </div>

      <div className="flex-1 p-6 space-y-6">
        {/* Quick Export */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <Download className="w-4 h-4 text-primary" />
              Exportar Relatório
            </CardTitle>
            <CardDescription>Seleccione a secção que pretende exportar para Excel</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label>Secção do Relatório</Label>
              <Select value={section} onValueChange={setSection}>
                <SelectTrigger className="max-w-sm">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {SECTIONS.map(s => (
                    <SelectItem key={s.value} value={s.value}>
                      <span className="flex items-center gap-2">
                        <s.icon className="w-3.5 h-3.5" />
                        {s.label}
                      </span>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            {selectedSection && (
              <div className="p-3 rounded-lg bg-muted/50 border border-border flex items-center gap-3">
                <selectedSection.icon className="w-5 h-5 text-primary flex-shrink-0" />
                <div>
                  <p className="text-sm font-medium">{selectedSection.label}</p>
                  <p className="text-xs text-muted-foreground">{selectedSection.description}</p>
                </div>
              </div>
            )}
            <Button onClick={() => exportMutation.mutate(section)} disabled={exportMutation.isPending}
              className="gap-2 w-full sm:w-auto" data-testid="button-export-report">
              {exportMutation.isPending
                ? <span className="flex items-center gap-2"><span className="btn-spinner" />A exportar...</span>
                : <><Download className="w-4 h-4" />Exportar Excel</>}
            </Button>
          </CardContent>
        </Card>

        {/* All Reports Grid */}
        <div>
          <h2 className="text-sm font-semibold text-foreground mb-3 flex items-center gap-2">
            <FileText className="w-4 h-4 text-primary" />
            Exportação Rápida por Secção
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {SECTIONS.map(sec => (
              <Card key={sec.value} className="hover-elevate">
                <CardContent className="p-4">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-start gap-3">
                      <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
                        style={{ background: "hsl(205, 75%, 90%)" }}>
                        <sec.icon className="w-5 h-5" style={{ color: "hsl(205, 75%, 35%)" }} />
                      </div>
                      <div>
                        <p className="font-medium text-sm text-foreground">{sec.label}</p>
                        <p className="text-xs text-muted-foreground mt-0.5">{sec.description}</p>
                      </div>
                    </div>
                  </div>
                  <Button variant="outline" size="sm" className="w-full mt-3 gap-1.5"
                    onClick={() => exportMutation.mutate(sec.value)}
                    disabled={exportMutation.isPending}>
                    <Download className="w-3.5 h-3.5" />
                    Exportar
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        <div className="rounded-lg border border-border bg-muted/30 p-4">
          <h3 className="text-sm font-semibold mb-2 flex items-center gap-2">
            <FileText className="w-4 h-4 text-muted-foreground" />
            Sobre os Relatórios
          </h3>
          <ul className="space-y-1 text-xs text-muted-foreground">
            <li>• Os relatórios são exportados em formato Microsoft Excel (.xlsx)</li>
            <li>• Cada secção é exportada numa aba separada do ficheiro</li>
            <li>• O relatório geral contém todas as secções num único ficheiro</li>
            <li>• Os dados exportados reflectem o estado actual da base de dados</li>
          </ul>
        </div>
      </div>
    </div>
  );
}
