import { useState, useRef } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Database, Download, Upload, Trash2, RefreshCw, Package, Building2, Archive, Layers, ArrowLeftRight, HardDrive } from "lucide-react";

function formatBytes(bytes: number) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}

export default function DatabasePage() {
  const { toast } = useToast();
  const [clearConfirm, setClearConfirm] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const { data: info, isLoading, refetch } = useQuery<any>({ queryKey: ["/api/database/info"] });

  const exportMutation = useMutation({
    mutationFn: async () => {
      const res = await fetch("/api/database/export", { credentials: "include" });
      if (!res.ok) throw new Error("Erro ao exportar");
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `hospital-db-${new Date().toISOString().split('T')[0]}.xlsx`;
      a.click();
      URL.revokeObjectURL(url);
    },
    onSuccess: () => toast({ title: "Base de dados exportada", description: "Ficheiro Excel transferido." }),
    onError: (e: any) => toast({ title: "Erro", description: e.message, variant: "destructive" }),
  });

  const importMutation = useMutation({
    mutationFn: async (file: File) => {
      const formData = new FormData();
      formData.append("file", file);
      const res = await fetch("/api/database/import", { method: "POST", body: formData, credentials: "include" });
      if (!res.ok) { const d = await res.json(); throw new Error(d.error || "Erro"); }
      return res.json();
    },
    onSuccess: (data) => {
      toast({ title: "Ficheiro processado", description: `Abas encontradas: ${data.sheets?.join(", ")}` });
      queryClient.invalidateQueries();
    },
    onError: (e: any) => toast({ title: "Erro ao importar", description: e.message, variant: "destructive" }),
  });

  const clearMutation = useMutation({
    mutationFn: () => apiRequest("POST", "/api/database/clear"),
    onSuccess: () => {
      queryClient.invalidateQueries();
      refetch();
      toast({ title: "Base de dados limpa", description: "Todos os dados foram eliminados." });
      setClearConfirm(false);
    },
    onError: (e: any) => toast({ title: "Erro", description: e.message, variant: "destructive" }),
  });

  const seedMutation = useMutation({
    mutationFn: () => apiRequest("POST", "/api/database/seed"),
    onSuccess: () => {
      queryClient.invalidateQueries();
      refetch();
      toast({ title: "Dados de exemplo carregados", description: "Os dados de exemplo foram inseridos na base de dados." });
    },
    onError: (e: any) => toast({ title: "Erro", description: e.message, variant: "destructive" }),
  });

  const stats = info?.stats;

  const statItems = [
    { label: "Medicamentos", value: stats?.total_products ?? 0, icon: Package },
    { label: "Fornecedores", value: stats?.total_suppliers ?? 0, icon: Building2 },
    { label: "Prateleiras", value: stats?.total_shelves ?? 0, icon: Archive },
    { label: "Lotes", value: stats?.total_lots ?? 0, icon: Layers },
    { label: "Entradas", value: stats?.total_entries ?? 0, icon: ArrowLeftRight },
    { label: "Saídas", value: stats?.total_exits ?? 0, icon: ArrowLeftRight },
  ];

  return (
    <div className="flex flex-col h-full overflow-y-auto">
      <div className="flex-shrink-0 px-6 py-4 border-b border-border bg-card/50">
        <div className="flex items-center gap-2">
          <Database className="w-5 h-5 text-primary" />
          <h1 className="text-xl font-bold">Base de Dados</h1>
        </div>
        <p className="text-sm text-muted-foreground mt-1">Gestão e manutenção da base de dados local</p>
      </div>

      <div className="flex-1 p-6 space-y-6">
        {/* DB Info */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base">
              <HardDrive className="w-4 h-4 text-primary" />
              Informações da Base de Dados
            </CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="flex items-center gap-2 text-muted-foreground">
                <div className="btn-spinner" />A carregar...
              </div>
            ) : (
              <div className="space-y-3">
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                  {statItems.map(item => (
                    <div key={item.label} className="flex items-center gap-3 p-3 rounded-lg bg-muted/40 border border-border">
                      <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ background: "hsl(205, 75%, 90%)" }}>
                        <item.icon className="w-4 h-4" style={{ color: "hsl(205, 75%, 35%)" }} />
                      </div>
                      <div>
                        <p className="text-lg font-bold text-foreground">{item.value}</p>
                        <p className="text-xs text-muted-foreground">{item.label}</p>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="flex flex-wrap gap-4 pt-2 text-sm text-muted-foreground border-t border-border">
                  <span><strong className="text-foreground">Tamanho:</strong> {info?.size ? formatBytes(info.size) : "—"}</span>
                  <span><strong className="text-foreground">Formato:</strong> SQLite 3</span>
                  <span><strong className="text-foreground">Modo:</strong> Local (Offline)</span>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Actions */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-2 gap-4">
          {/* Export */}
          <Card className="hover-elevate">
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2">
                <Download className="w-4 h-4 text-primary" />
                Exportar Base de Dados
              </CardTitle>
              <CardDescription>Transfere todos os dados em formato Excel</CardDescription>
            </CardHeader>
            <CardContent>
              <Button onClick={() => exportMutation.mutate()} disabled={exportMutation.isPending}
                className="w-full gap-2" data-testid="button-export-db">
                {exportMutation.isPending
                  ? <span className="flex items-center gap-2"><span className="btn-spinner" />A exportar...</span>
                  : <><Download className="w-4 h-4" />Exportar Excel</>}
              </Button>
            </CardContent>
          </Card>

          {/* Import */}
          <Card className="hover-elevate">
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2">
                <Upload className="w-4 h-4 text-primary" />
                Importar Base de Dados
              </CardTitle>
              <CardDescription>Importa dados a partir de um ficheiro Excel</CardDescription>
            </CardHeader>
            <CardContent>
              <input type="file" accept=".xlsx,.xls" ref={fileRef} className="hidden"
                onChange={e => { const f = e.target.files?.[0]; if (f) importMutation.mutate(f); e.target.value = ""; }} />
              <Button variant="outline" onClick={() => fileRef.current?.click()} disabled={importMutation.isPending}
                className="w-full gap-2" data-testid="button-import-db">
                {importMutation.isPending
                  ? <span className="flex items-center gap-2"><span className="btn-spinner" />A importar...</span>
                  : <><Upload className="w-4 h-4" />Seleccionar Ficheiro</>}
              </Button>
            </CardContent>
          </Card>

          {/* Seed */}
          <Card className="hover-elevate">
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2">
                <RefreshCw className="w-4 h-4 text-primary" />
                Carregar Dados de Exemplo
              </CardTitle>
              <CardDescription>Insere dados de demonstração (apenas se a BD estiver vazia)</CardDescription>
            </CardHeader>
            <CardContent>
              <Button variant="outline" onClick={() => seedMutation.mutate()} disabled={seedMutation.isPending}
                className="w-full gap-2" data-testid="button-seed-db">
                {seedMutation.isPending
                  ? <span className="flex items-center gap-2"><span className="btn-spinner" />A carregar...</span>
                  : <><RefreshCw className="w-4 h-4" />Carregar Exemplos</>}
              </Button>
            </CardContent>
          </Card>

          {/* Clear */}
          <Card className="hover-elevate border-destructive/30">
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2 text-destructive">
                <Trash2 className="w-4 h-4" />
                Limpar Base de Dados
              </CardTitle>
              <CardDescription className="text-destructive/70">
                Elimina todos os dados (irreversível)
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button variant="destructive" onClick={() => setClearConfirm(true)} className="w-full gap-2"
                data-testid="button-clear-db">
                <Trash2 className="w-4 h-4" />
                Limpar Todos os Dados
              </Button>
            </CardContent>
          </Card>
        </div>

        <div className="rounded-lg border border-border bg-muted/30 p-4">
          <h3 className="text-sm font-semibold mb-2 flex items-center gap-2">
            <Database className="w-4 h-4 text-muted-foreground" />
            Informação Técnica
          </h3>
          <ul className="space-y-1 text-xs text-muted-foreground">
            <li>• Base de dados local SQLite — não requer internet</li>
            <li>• Ficheiro: <code className="font-mono bg-muted px-1 rounded">hospital.db</code> na pasta do sistema</li>
            <li>• Faça backups regulares usando a opção de exportação</li>
            <li>• A limpeza da base de dados não elimina os utilizadores do sistema</li>
          </ul>
        </div>
      </div>

      <AlertDialog open={clearConfirm} onOpenChange={setClearConfirm}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="text-destructive">Limpar toda a base de dados?</AlertDialogTitle>
            <AlertDialogDescription>
              Esta acção é <strong>irreversível</strong>. Todos os medicamentos, fornecedores, prateleiras, lotes e movimentações serão eliminados permanentemente.
              <br /><br />
              Recomendamos exportar os dados antes de prosseguir.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={() => clearMutation.mutate()}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              {clearMutation.isPending
                ? <span className="flex items-center gap-2"><span className="btn-spinner" />A limpar...</span>
                : "Confirmar Limpeza"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
