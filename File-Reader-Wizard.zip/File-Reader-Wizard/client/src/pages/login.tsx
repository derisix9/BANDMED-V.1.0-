import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { User, Lock, Shield, Eye, EyeOff } from "lucide-react";
import loginLogo from "@assets/2d29899d85227a37d2321e36278d0eca_1772145177183.png";

export default function Login() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const { login, isLoggingIn } = useAuth();
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username || !password) {
      toast({ title: "Campos obrigatórios", description: "Preencha o utilizador e a senha.", variant: "destructive" });
      return;
    }
    try {
      await login({ username, password });
    } catch (err: any) {
      toast({ title: "Erro de autenticação", description: err.message || "Utilizador ou senha inválidos.", variant: "destructive" });
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 relative overflow-hidden"
      style={{ background: "linear-gradient(135deg, hsl(215, 42%, 14%) 0%, hsl(205, 60%, 22%) 50%, hsl(215, 42%, 10%) 100%)" }}>

      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {[...Array(4)].map((_, i) => (
          <div key={i} className="absolute rounded-full opacity-5"
            style={{
              width: `${200 + i * 150}px`, height: `${200 + i * 150}px`,
              border: "1px solid hsl(195, 75%, 50%)",
              top: "50%", left: "50%",
              transform: "translate(-50%, -50%)",
            }}
          />
        ))}
        <div className="absolute top-1/4 -left-20 w-64 h-64 rounded-full opacity-10"
          style={{ background: "hsl(195, 75%, 45%)", filter: "blur(60px)" }} />
        <div className="absolute bottom-1/4 -right-20 w-64 h-64 rounded-full opacity-10"
          style={{ background: "hsl(175, 65%, 38%)", filter: "blur(60px)" }} />
      </div>

      <div className="w-full max-w-md relative z-10">
        <div className="text-center mb-8">
          <div className="flex justify-center mb-4">
            <div className="relative">
              <div className="absolute inset-0 rounded-full opacity-30"
                style={{ background: "hsl(195, 75%, 50%)", filter: "blur(15px)", transform: "scale(1.4)" }} />
              <div className="relative w-20 h-20 rounded-full flex items-center justify-center bg-white/10 backdrop-blur-sm overflow-hidden">
                <img src={loginLogo} alt="BANDMED Logo" className="w-14 h-14 object-contain" />
              </div>
            </div>
          </div>
          <div className="flex items-center justify-center gap-2 mb-1">
            <Shield className="w-3.5 h-3.5" style={{ color: "hsl(195, 75%, 60%)" }} />
            <span className="text-xs font-semibold tracking-widest uppercase text-white/60">Sistema Seguro</span>
          </div>
          <h1 className="text-3xl font-black text-white tracking-tighter">BANDMED</h1>
          <p className="text-sm font-medium uppercase tracking-widest" style={{ color: "hsl(195, 75%, 60%)" }}>
            Gestão Hospitalar
          </p>
        </div>

        <Card className="border-0 shadow-2xl" style={{ background: "rgba(255,255,255,0.05)", backdropFilter: "blur(20px)", border: "1px solid rgba(255,255,255,0.1)" }}>
          <CardHeader className="pb-4">
            <CardTitle className="text-white text-lg text-center">Entrar no Sistema</CardTitle>
            <CardDescription className="text-center text-white/50">
              Introduza as suas credenciais de acesso
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label className="text-white/80 text-sm flex items-center gap-2">
                  <User className="w-3.5 h-3.5" />
                  Utilizador
                </Label>
                <Input
                  data-testid="input-username"
                  type="text"
                  placeholder="Nome de utilizador"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="border-white/20 text-white placeholder:text-white/30 focus:border-white/40"
                  style={{ background: "rgba(255,255,255,0.08)" }}
                  autoComplete="username"
                />
              </div>
              <div className="space-y-2">
                <Label className="text-white/80 text-sm flex items-center gap-2">
                  <Lock className="w-3.5 h-3.5" />
                  Senha
                </Label>
                <div className="relative">
                  <Input
                    data-testid="input-password"
                    type={showPassword ? "text" : "password"}
                    placeholder="Senha de acesso"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="border-white/20 text-white placeholder:text-white/30 focus:border-white/40 pr-10"
                    style={{ background: "rgba(255,255,255,0.08)" }}
                    autoComplete="current-password"
                  />
                  <button type="button" onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-white/40 hover:text-white/70 transition-colors">
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>
              <Button data-testid="button-login" type="submit" className="w-full h-11 font-semibold mt-2"
                disabled={isLoggingIn}
                style={{ background: "linear-gradient(135deg, hsl(195, 75%, 38%), hsl(175, 65%, 32%))" }}>
                {isLoggingIn ? (
                  <span className="flex items-center gap-2">
                    <span className="btn-spinner" />
                    A autenticar...
                  </span>
                ) : "Entrar"}
              </Button>
            </form>
          </CardContent>
        </Card>

        <p className="text-center text-white/40 text-xs mt-6 font-medium">
          Sistema desenvolvido por Engº DFBANDE
        </p>
        <p className="text-center text-white/20 text-[10px] mt-1 uppercase tracking-tighter">
          Sistema Offline • v1.0.0 • BANDMED
        </p>
      </div>
    </div>
  );
}
