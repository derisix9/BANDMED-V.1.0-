import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Archive, Plus, Search, Edit, Trash2, Eye, Package, LayoutGrid, Layers } from "lucide-react";

const emptyForm = { name: "", capacity: "", section: "" };

function OccupancyBar({ count, capacity }: { count: number; capacity?: number }) {
  if (!capacity) return <div className="text-xs text-muted-foreground">{count} produto{count !== 1 ? "s" : ""}</div>;
  const pct = Math.min(100, (count / capacity) * 100);
  const color = pct >= 90 ? "hsl(0, 72%, 51%)" : pct >= 70 ? "hsl(38, 92%, 45%)" : "hsl(142, 72%, 35%)";
  return (
    <div className="space-y-1">
      <div className="flex justify-between text-xs">
        <span className="text-muted-foreground">{count} / {capacity}</span>
        <span className="font-medium" style={{ color }}>{pct.toFixed(0)}%</span>
      </div>
      <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
        <div className="h-full rounded-full transition-all" style={{ width: `${pct}%`, background: color }} />
      </div>
    </div>
  );
}

export default function Shelves() {
  const { toast } = useToast();
  const [search, setSearch] = useState("");
  const [isOpen, setIsOpen] = useState(false);
  const [editItem, setEditItem] = useState<any>(null);
  const [deleteId, setDeleteId] = useState<number | null>(null);
  const [viewShelf, setViewShelf] = useState<any>(null);
  const [form, setForm] = useState(emptyForm);

  const { data: shelves = [], isLoading } = useQuery<any[]>({ queryKey: ["/api/shelves"] });
  const { data: shelfProducts = [] } = useQuery<any[]>({
    queryKey: ["/api/shelves", viewShelf?.id, "products"],
    enabled: !!viewShelf,
    queryFn: async () => {
      const res = await fetch(`/api/shelves/${viewShelf.id}/products`, { credentials: "include" });
      return res.json();
    },
  });

  const saveMutation = useMutation({
    mutationFn: async (data: any) => {
      if (editItem) return (await apiRequest("PUT", `/api/shelves/${editItem.id}`, data)).json();
      return (await apiRequest("POST", "/api/shelves", data)).json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/shelves"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      toast({ title: editItem ? "Prateleira actualizada" : "Prateleira cadastrada" });
      setIsOpen(false);
    },
    onError: (e: any) => toast({ title: "Erro", description: e.message, variant: "destructive" }),
  });

  const deleteMutation = useMutation({
    mutationFn: (id: number) => apiRequest("DELETE", `/api/shelves/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/shelves"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      toast({ title: "Prateleira eliminada" });
      setDeleteId(null);
    },
    onError: (e: any) => toast({ title: "Erro", description: e.message, variant: "destructive" }),
  });

  const openCreate = () => { setEditItem(null); setForm(emptyForm); setIsOpen(true); };
  const openEdit = (item: any) => {
    setEditItem(item);
    setForm({ name: item.name || "", capacity: item.capacity != null ? String(item.capacity) : "", section: item.section || "" });
    setIsOpen(true);
  };
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name.trim()) { toast({ title: "Nome obrigatório", variant: "destructive" }); return; }
    saveMutation.mutate({ name: form.name.trim(), capacity: form.capacity ? Number(form.capacity) : null, section: form.section || null });
  };

  const filtered = (shelves as any[]).filter(s =>
    s.name?.toLowerCase().includes(search.toLowerCase()) ||
    s.section?.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="flex flex-col h-full overflow-y-auto">
      <div className="flex-shrink-0 px-6 py-4 border-b border-border bg-card/50">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <Archive className="w-5 h-5 text-primary" />
            <h1 className="text-xl font-bold">Prateleiras</h1>
            <span className="badge-info px-2 py-0.5 rounded-full text-xs font-medium">{filtered.length}</span>
          </div>
          <Button onClick={openCreate} className="gap-2" data-testid="button-add-shelf">
            <Plus className="w-4 h-4" /> Nova Prateleira
          </Button>
        </div>
        <div className="mt-3 relative max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input placeholder="Pesquisar prateleiras..." className="pl-9" value={search}
            onChange={e => setSearch(e.target.value)} />
        </div>
      </div>

      <div className="flex-1 p-6">
        {isLoading ? (
          <div className="flex items-center justify-center h-40">
            <div className="btn-spinner w-8 h-8 border-2 border-primary/30 border-t-primary" />
          </div>
        ) : filtered.length === 0 ? (
          <Card>
            <CardContent className="flex flex-col items-center justify-center py-12 gap-3">
              <Archive className="w-12 h-12 text-muted-foreground/30" />
              <p className="text-muted-foreground font-medium">Nenhuma prateleira encontrada</p>
              <Button onClick={openCreate} variant="outline" className="gap-2">
                <Plus className="w-4 h-4" /> Adicionar prateleira
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {filtered.map((s: any) => {
              const count = s.product_count || 0;
              const capacity = s.capacity;
              const pct = capacity ? Math.min(100, (count / capacity) * 100) : null;
              const statusColor = pct === null ? "hsl(205, 75%, 35%)" : pct >= 90 ? "hsl(0, 72%, 51%)" : pct >= 70 ? "hsl(38, 92%, 45%)" : "hsl(142, 72%, 35%)";

              return (
                <Card key={s.id} className="hover-elevate">
                  <CardHeader className="pb-3">
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-center gap-2 min-w-0">
                        <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0"
                          style={{ background: `${statusColor}18` }}>
                          <Archive className="w-4 h-4" style={{ color: statusColor }} />
                        </div>
                        <div className="min-w-0">
                          <p className="font-semibold text-sm text-foreground truncate">{s.name}</p>
                          {s.section && <p className="text-xs text-muted-foreground truncate">{s.section}</p>}
                        </div>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="pt-0 space-y-3">
                    <OccupancyBar count={count} capacity={capacity} />
                    <div className="flex items-center justify-between text-xs text-muted-foreground">
                      <span className="flex items-center gap-1"><Package className="w-3 h-3" />{count} produto{count !== 1 ? "s" : ""}</span>
                      {capacity && <span className="flex items-center gap-1"><Layers className="w-3 h-3" />Cap. {capacity}</span>}
                    </div>
                    <div className="flex items-center gap-1 pt-1">
                      <Button size="icon" variant="ghost" onClick={() => setViewShelf(s)}
                        className="w-8 h-8 flex-1" data-testid={`button-view-shelf-${s.id}`}>
                        <Eye className="w-3.5 h-3.5" />
                      </Button>
                      <Button size="icon" variant="ghost" onClick={() => openEdit(s)}
                        className="w-8 h-8 flex-1" data-testid={`button-edit-shelf-${s.id}`}>
                        <Edit className="w-3.5 h-3.5" />
                      </Button>
                      <Button size="icon" variant="ghost" onClick={() => setDeleteId(s.id)}
                        className="w-8 h-8 flex-1 text-destructive hover:text-destructive"
                        data-testid={`button-delete-shelf-${s.id}`}>
                        <Trash2 className="w-3.5 h-3.5" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}
      </div>

      {/* Form Dialog */}
      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Archive className="w-5 h-5 text-primary" />
              {editItem ? "Editar Prateleira" : "Nova Prateleira"}
            </DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4 py-2">
            <div className="space-y-2">
              <Label className="flex items-center gap-1.5"><Archive className="w-3.5 h-3.5" />Nome *</Label>
              <Input placeholder="Ex: Prateleira A1" value={form.name}
                onChange={e => setForm({ ...form, name: e.target.value })} data-testid="input-shelf-name" />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="flex items-center gap-1.5"><Layers className="w-3.5 h-3.5" />Capacidade</Label>
                <Input type="number" min="0" placeholder="Máx. produtos" value={form.capacity}
                  onChange={e => setForm({ ...form, capacity: e.target.value })} />
              </div>
              <div className="space-y-2">
                <Label className="flex items-center gap-1.5"><LayoutGrid className="w-3.5 h-3.5" />Secção</Label>
                <Input placeholder="Ex: Secção A" value={form.section}
                  onChange={e => setForm({ ...form, section: e.target.value })} />
              </div>
            </div>
            <DialogFooter className="gap-2 pt-2">
              <Button type="button" variant="outline" onClick={() => setIsOpen(false)}>Cancelar</Button>
              <Button type="submit" disabled={saveMutation.isPending}>
                {saveMutation.isPending ? <span className="flex items-center gap-2"><span className="btn-spinner" />A guardar...</span>
                  : (editItem ? "Actualizar" : "Cadastrar")}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* View Products Dialog */}
      <Dialog open={!!viewShelf} onOpenChange={open => !open && setViewShelf(null)}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Archive className="w-5 h-5 text-primary" />
              {viewShelf?.name} — Produtos
            </DialogTitle>
          </DialogHeader>
          <div className="py-2">
            {(shelfProducts as any[]).length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <Package className="w-10 h-10 mx-auto mb-2 opacity-30" />
                <p className="text-sm">Nenhum produto nesta prateleira</p>
              </div>
            ) : (
              <div className="space-y-2">
                {(shelfProducts as any[]).map((p: any) => (
                  <div key={p.id} className="flex items-center gap-3 p-3 rounded-lg bg-muted/40 border border-border">
                    <div className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0"
                      style={{ background: "hsl(205, 75%, 90%)" }}>
                      <Package className="w-4 h-4" style={{ color: "hsl(205, 75%, 35%)" }} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-foreground truncate">{p.name}</p>
                      <p className="text-xs text-muted-foreground">{p.form || ""}{p.pharmacological_group ? ` • ${p.pharmacological_group}` : ""}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>

      <AlertDialog open={deleteId !== null} onOpenChange={open => !open && setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Eliminar Prateleira?</AlertDialogTitle>
            <AlertDialogDescription>Os produtos associados ficarão sem prateleira.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={() => deleteId && deleteMutation.mutate(deleteId)}
              className="bg-destructive text-destructive-foreground">
              {deleteMutation.isPending ? <span className="flex items-center gap-2"><span className="btn-spinner" />A eliminar...</span> : "Eliminar"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
