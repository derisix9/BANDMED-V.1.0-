import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Package, Building2, Archive, Layers, TrendingUp, TrendingDown,
  AlertTriangle, Bell, Activity, BarChart3, Clock
} from "lucide-react";
import { format } from "date-fns";
import { pt } from "date-fns/locale";

function StatCard({ title, value, icon: Icon, color, sub }: {
  title: string; value: number | string; icon: any; color: string; sub?: string;
}) {
  return (
    <Card className="hover-elevate">
      <CardContent className="p-5">
        <div className="flex items-start justify-between gap-3">
          <div className="flex-1 min-w-0">
            <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-1">{title}</p>
            <p className="text-2xl font-bold text-foreground">{value}</p>
            {sub && <p className="text-xs text-muted-foreground mt-1">{sub}</p>}
          </div>
          <div className="w-11 h-11 rounded-xl flex items-center justify-center flex-shrink-0"
            style={{ background: color + "18" }}>
            <Icon className="w-5 h-5" style={{ color }} />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function MovementBadge({ type }: { type: string }) {
  return (
    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium ${type === 'entrada' ? 'badge-active' : 'badge-warning'}`}>
      {type === 'entrada' ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
      {type === 'entrada' ? 'Entrada' : 'Saída'}
    </span>
  );
}

export default function Dashboard() {
  const { user } = useAuth();
  const { data: stats, isLoading: statsLoading } = useQuery<any>({ queryKey: ["/api/dashboard/stats"] });
  const { data: topProducts } = useQuery<any[]>({ queryKey: ["/api/dashboard/top-products"] });
  const { data: recentMovements } = useQuery<any[]>({ queryKey: ["/api/dashboard/recent-movements"] });
  const { data: alerts } = useQuery<any[]>({ queryKey: ["/api/alerts"] });

  const criticalAlerts = alerts?.filter((a: any) => a.severity === 'critico' && !a.is_read) || [];
  const warningAlerts = alerts?.filter((a: any) => a.severity === 'aviso' && !a.is_read) || [];

  return (
    <div className="flex flex-col h-full overflow-y-auto">
      <div className="flex-shrink-0 px-6 py-4 border-b border-border bg-card/50">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h1 className="text-xl font-bold text-foreground">Dashboard</h1>
            <p className="text-sm text-muted-foreground">
              {format(new Date(), "EEEE, d 'de' MMMM 'de' yyyy", { locale: pt })}
            </p>
          </div>
          <div className="flex items-center gap-3">
            {criticalAlerts.length > 0 && (
              <span className="flex items-center gap-1.5 text-xs badge-critical px-2.5 py-1 rounded-full font-medium">
                <AlertTriangle className="w-3 h-3" />
                {criticalAlerts.length} crítico{criticalAlerts.length !== 1 ? "s" : ""}
              </span>
            )}
            <div className="text-right">
              <p className="text-sm font-semibold text-foreground">{user?.name}</p>
              <p className="text-xs text-muted-foreground">{user?.role}</p>
            </div>
          </div>
        </div>
      </div>

      <div className="flex-1 p-6 space-y-6">
        {/* Main Stats */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-4 gap-4">
          <StatCard title="Medicamentos" value={statsLoading ? "..." : (stats?.total_products ?? 0)}
            icon={Package} color="hsl(205, 75%, 40%)" sub="cadastrados" />
          <StatCard title="Fornecedores" value={statsLoading ? "..." : (stats?.total_suppliers ?? 0)}
            icon={Building2} color="hsl(175, 65%, 35%)" sub="activos" />
          <StatCard title="Prateleiras" value={statsLoading ? "..." : (stats?.total_shelves ?? 0)}
            icon={Archive} color="hsl(270, 60%, 50%)" sub="no depósito" />
          <StatCard title="Lotes" value={statsLoading ? "..." : (stats?.total_lots ?? 0)}
            icon={Layers} color="hsl(38, 92%, 45%)" sub="registados" />
        </div>

        {/* Movement & Alert Stats */}
        <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard title="Total Entradas" value={statsLoading ? "..." : (stats?.total_entries ?? 0)}
            icon={TrendingUp} color="hsl(142, 72%, 35%)" sub="unidades recebidas" />
          <StatCard title="Total Saídas" value={statsLoading ? "..." : (stats?.total_exits ?? 0)}
            icon={TrendingDown} color="hsl(0, 72%, 51%)" sub="unidades distribuídas" />
          <StatCard title="Stock Mínimo" value={statsLoading ? "..." : (stats?.low_stock_count ?? 0)}
            icon={AlertTriangle} color="hsl(38, 92%, 45%)" sub="produtos em alerta" />
          <StatCard title="A Vencer (30d)" value={statsLoading ? "..." : (stats?.expiring_soon_count ?? 0)}
            icon={Bell} color="hsl(0, 65%, 50%)" sub="lotes críticos" />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
          {/* Top Products by Stock */}
          <Card className="lg:col-span-2">
            <CardHeader className="pb-3 flex flex-row items-center gap-2">
              <BarChart3 className="w-4 h-4 text-primary" />
              <CardTitle className="text-sm font-semibold">Top Medicamentos por Stock</CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="space-y-2">
                {(!topProducts || topProducts.length === 0) ? (
                  <p className="text-sm text-muted-foreground text-center py-4">Sem dados</p>
                ) : topProducts.slice(0, 8).map((p: any, i: number) => {
                  const max = topProducts[0]?.current_stock || 1;
                  const pct = Math.max(5, (p.current_stock / max) * 100);
                  return (
                    <div key={i} className="space-y-1">
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-xs text-foreground truncate flex-1">{p.name}</span>
                        <span className="text-xs font-mono font-semibold text-foreground flex-shrink-0">{p.current_stock}</span>
                      </div>
                      <div className="w-full h-1.5 bg-muted rounded-full overflow-hidden">
                        <div className="h-full rounded-full transition-all"
                          style={{ width: `${pct}%`, background: "linear-gradient(90deg, hsl(205, 75%, 40%), hsl(175, 65%, 35%))" }} />
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>

          {/* Recent Movements */}
          <Card className="lg:col-span-3">
            <CardHeader className="pb-3 flex flex-row items-center gap-2">
              <Activity className="w-4 h-4 text-primary" />
              <CardTitle className="text-sm font-semibold">Últimas Movimentações</CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="space-y-2">
                {(!recentMovements || recentMovements.length === 0) ? (
                  <p className="text-sm text-muted-foreground text-center py-4">Sem movimentações recentes</p>
                ) : recentMovements.map((m: any) => (
                  <div key={m.id} className="flex items-center gap-3 py-2 border-b border-border last:border-0">
                    <MovementBadge type={m.type} />
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-medium text-foreground truncate">{m.product_name}</p>
                      {m.destination && <p className="text-xs text-muted-foreground truncate">→ {m.destination}</p>}
                    </div>
                    <div className="text-right flex-shrink-0">
                      <p className="text-xs font-semibold text-foreground">{m.quantity} un</p>
                      <p className="text-xs text-muted-foreground">
                        {format(new Date(m.movement_date), "dd/MM")}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Active Alerts */}
        {(criticalAlerts.length > 0 || warningAlerts.length > 0) && (
          <Card className="border-destructive/30">
            <CardHeader className="pb-3 flex flex-row items-center gap-2">
              <Bell className="w-4 h-4 text-destructive" />
              <CardTitle className="text-sm font-semibold text-destructive">Alertas Activos</CardTitle>
              <span className="ml-auto text-xs badge-critical px-2 py-0.5 rounded-full font-medium">
                {criticalAlerts.length + warningAlerts.length} alerta{criticalAlerts.length + warningAlerts.length !== 1 ? "s" : ""}
              </span>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {[...criticalAlerts.slice(0, 3), ...warningAlerts.slice(0, 3)].map((a: any) => (
                  <div key={a.id} className={`flex items-start gap-2 p-3 rounded-lg ${a.severity === 'critico' ? 'badge-critical' : 'badge-warning'}`}
                    style={{ background: a.severity === 'critico' ? 'hsl(0, 72%, 97%)' : 'hsl(38, 92%, 96%)' }}>
                    <AlertTriangle className="w-3.5 h-3.5 mt-0.5 flex-shrink-0" />
                    <div className="min-w-0">
                      <p className="text-xs font-semibold truncate">{a.title}</p>
                      <p className="text-xs opacity-80 truncate">{a.message}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Stock Status Summary */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <Card>
            <CardContent className="p-4 flex items-center gap-3">
              <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ background: "hsl(0, 72%, 95%)" }}>
                <Clock className="w-5 h-5" style={{ color: "hsl(0, 72%, 51%)" }} />
              </div>
              <div>
                <p className="text-lg font-bold">{stats?.expired_count ?? 0}</p>
                <p className="text-xs text-muted-foreground">Lotes Vencidos</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 flex items-center gap-3">
              <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ background: "hsl(38, 92%, 94%)" }}>
                <AlertTriangle className="w-5 h-5" style={{ color: "hsl(38, 92%, 45%)" }} />
              </div>
              <div>
                <p className="text-lg font-bold">{stats?.expiring_soon_count ?? 0}</p>
                <p className="text-xs text-muted-foreground">A Vencer em 30 dias</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 flex items-center gap-3">
              <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ background: "hsl(142, 72%, 94%)" }}>
                <Package className="w-5 h-5" style={{ color: "hsl(142, 72%, 35%)" }} />
              </div>
              <div>
                <p className="text-lg font-bold">{(stats?.total_entries ?? 0) - (stats?.total_exits ?? 0)}</p>
                <p className="text-xs text-muted-foreground">Stock Total Actual</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
