import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Card, CardContent } from "@/components/ui/card";
import { Layers, Plus, Search, Edit, Trash2, Calendar, Package, Building2, Hash, AlertTriangle, CheckCircle, Clock } from "lucide-react";
import { format, parseISO, differenceInDays } from "date-fns";

const emptyForm = { lot_number: "", expiry_date: "", quantity: "", supplier_id: "", product_id: "", barcode: "" };

function LotStatusBadge({ status, expiryDate }: { status: string; expiryDate: string }) {
  const today = new Date();
  let expDate: Date;
  try { expDate = parseISO(expiryDate); } catch { expDate = new Date(); }
  const days = differenceInDays(expDate, today);

  if (status === "vencido") return (
    <span className="badge-expired inline-flex items-center gap-1 text-xs px-2 py-0.5 rounded-full font-medium">
      <Clock className="w-3 h-3" />Vencido
    </span>
  );
  if (status === "a_vencer") return (
    <span className="badge-warning inline-flex items-center gap-1 text-xs px-2 py-0.5 rounded-full font-medium">
      <AlertTriangle className="w-3 h-3" />A vencer ({days}d)
    </span>
  );
  return (
    <span className="badge-active inline-flex items-center gap-1 text-xs px-2 py-0.5 rounded-full font-medium">
      <CheckCircle className="w-3 h-3" />Activo
    </span>
  );
}

export default function Lots() {
  const { toast } = useToast();
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [isOpen, setIsOpen] = useState(false);
  const [editItem, setEditItem] = useState<any>(null);
  const [deleteId, setDeleteId] = useState<number | null>(null);
  const [form, setForm] = useState(emptyForm);

  const { data: lots = [], isLoading } = useQuery<any[]>({ queryKey: ["/api/lots"] });
  const { data: products = [] } = useQuery<any[]>({ queryKey: ["/api/products"] });
  const { data: suppliers = [] } = useQuery<any[]>({ queryKey: ["/api/suppliers"] });

  const saveMutation = useMutation({
    mutationFn: async (data: any) => {
      if (editItem) return (await apiRequest("PUT", `/api/lots/${editItem.id}`, data)).json();
      return (await apiRequest("POST", "/api/lots", data)).json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/lots"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      queryClient.invalidateQueries({ queryKey: ["/api/alerts"] });
      toast({ title: editItem ? "Lote actualizado" : "Lote cadastrado" });
      setIsOpen(false);
    },
    onError: (e: any) => toast({ title: "Erro", description: e.message, variant: "destructive" }),
  });

  const deleteMutation = useMutation({
    mutationFn: (id: number) => apiRequest("DELETE", `/api/lots/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/lots"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      toast({ title: "Lote eliminado" });
      setDeleteId(null);
    },
    onError: (e: any) => toast({ title: "Erro", description: e.message, variant: "destructive" }),
  });

  const openCreate = () => { setEditItem(null); setForm(emptyForm); setIsOpen(true); };
  const openEdit = (item: any) => {
    setEditItem(item);
    setForm({
      lot_number: item.lot_number || "", expiry_date: item.expiry_date || "",
      quantity: item.quantity != null ? String(item.quantity) : "",
      supplier_id: item.supplier_id ? String(item.supplier_id) : "",
      product_id: item.product_id ? String(item.product_id) : "",
      barcode: item.barcode || "",
    });
    setIsOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.lot_number || !form.expiry_date || !form.product_id) {
      toast({ title: "Número de lote, validade e produto são obrigatórios", variant: "destructive" }); return;
    }
    saveMutation.mutate({
      lot_number: form.lot_number.trim(),
      expiry_date: form.expiry_date,
      quantity: form.quantity ? Number(form.quantity) : 0,
      supplier_id: form.supplier_id ? Number(form.supplier_id) : null,
      product_id: Number(form.product_id),
      barcode: form.barcode || null,
    });
  };

  const filtered = (lots as any[]).filter(l => {
    const matchSearch = l.lot_number?.toLowerCase().includes(search.toLowerCase()) ||
      l.product_name?.toLowerCase().includes(search.toLowerCase()) ||
      l.supplier_name?.toLowerCase().includes(search.toLowerCase());
    const matchStatus = statusFilter === "all" || l.status === statusFilter;
    return matchSearch && matchStatus;
  });

  return (
    <div className="flex flex-col h-full overflow-y-auto">
      <div className="flex-shrink-0 px-6 py-4 border-b border-border bg-card/50">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <Layers className="w-5 h-5 text-primary" />
            <h1 className="text-xl font-bold">Lotes</h1>
            <span className="badge-info px-2 py-0.5 rounded-full text-xs font-medium">{filtered.length}</span>
          </div>
          <Button onClick={openCreate} className="gap-2" data-testid="button-add-lot">
            <Plus className="w-4 h-4" /> Novo Lote
          </Button>
        </div>
        <div className="mt-3 flex flex-wrap gap-3">
          <div className="relative flex-1 min-w-48 max-w-sm">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input placeholder="Pesquisar lotes..." className="pl-9" value={search}
              onChange={e => setSearch(e.target.value)} />
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-40"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos os status</SelectItem>
              <SelectItem value="ativo">Activos</SelectItem>
              <SelectItem value="a_vencer">A vencer</SelectItem>
              <SelectItem value="vencido">Vencidos</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="flex-1 p-6">
        {isLoading ? (
          <div className="flex items-center justify-center h-40">
            <div className="btn-spinner w-8 h-8 border-2 border-primary/30 border-t-primary" />
          </div>
        ) : filtered.length === 0 ? (
          <Card>
            <CardContent className="flex flex-col items-center justify-center py-12 gap-3">
              <Layers className="w-12 h-12 text-muted-foreground/30" />
              <p className="text-muted-foreground font-medium">Nenhum lote encontrado</p>
              <Button onClick={openCreate} variant="outline" className="gap-2">
                <Plus className="w-4 h-4" /> Adicionar lote
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="rounded-lg border border-border overflow-hidden bg-card">
            <div className="overflow-x-auto">
              <table className="data-table">
                <thead className="bg-muted/50 border-b border-border">
                  <tr>
                    <th className="text-left data-table">Nº Lote</th>
                    <th className="text-left data-table">Medicamento</th>
                    <th className="text-left data-table hidden sm:table-cell">Fornecedor</th>
                    <th className="text-center data-table">Quantidade</th>
                    <th className="text-left data-table hidden md:table-cell">Validade</th>
                    <th className="text-center data-table">Status</th>
                    <th className="text-center data-table">Ações</th>
                  </tr>
                </thead>
                <tbody>
                  {filtered.map((l: any) => (
                    <tr key={l.id} className="border-b border-border last:border-0 hover:bg-muted/30 transition-colors">
                      <td className="data-table">
                        <div className="flex items-center gap-2">
                          <Hash className="w-3.5 h-3.5 text-muted-foreground flex-shrink-0" />
                          <span className="font-mono text-sm font-medium">{l.lot_number}</span>
                        </div>
                      </td>
                      <td className="data-table">
                        <div className="flex items-center gap-1.5 text-sm text-foreground">
                          <Package className="w-3.5 h-3.5 text-muted-foreground flex-shrink-0" />
                          <span className="truncate max-w-36">{l.product_name}</span>
                        </div>
                      </td>
                      <td className="data-table hidden sm:table-cell">
                        <div className="flex items-center gap-1.5 text-sm text-muted-foreground">
                          <Building2 className="w-3.5 h-3.5 flex-shrink-0" />
                          <span className="truncate max-w-32">{l.supplier_name || "—"}</span>
                        </div>
                      </td>
                      <td className="data-table text-center">
                        <span className="text-sm font-bold">{l.quantity}</span>
                        <span className="text-xs text-muted-foreground ml-1">un</span>
                      </td>
                      <td className="data-table hidden md:table-cell">
                        <div className="flex items-center gap-1.5 text-sm">
                          <Calendar className="w-3.5 h-3.5 text-muted-foreground flex-shrink-0" />
                          <span className={l.status === "vencido" ? "text-destructive font-medium" : l.status === "a_vencer" ? "font-medium" : ""}>
                            {l.expiry_date ? format(parseISO(l.expiry_date), "dd/MM/yyyy") : "—"}
                          </span>
                        </div>
                      </td>
                      <td className="data-table text-center">
                        <LotStatusBadge status={l.status} expiryDate={l.expiry_date} />
                      </td>
                      <td className="data-table text-center">
                        <div className="flex items-center justify-center gap-1">
                          <Button size="icon" variant="ghost" onClick={() => openEdit(l)} className="w-8 h-8">
                            <Edit className="w-3.5 h-3.5" />
                          </Button>
                          <Button size="icon" variant="ghost" onClick={() => setDeleteId(l.id)}
                            className="w-8 h-8 text-destructive hover:text-destructive">
                            <Trash2 className="w-3.5 h-3.5" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>

      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Layers className="w-5 h-5 text-primary" />
              {editItem ? "Editar Lote" : "Novo Lote"}
            </DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4 py-2">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="flex items-center gap-1.5"><Hash className="w-3.5 h-3.5" />Número de Lote *</Label>
                <Input placeholder="Ex: L001-2024" value={form.lot_number}
                  onChange={e => setForm({ ...form, lot_number: e.target.value })} data-testid="input-lot-number" />
              </div>
              <div className="space-y-2">
                <Label className="flex items-center gap-1.5"><Calendar className="w-3.5 h-3.5" />Data de Validade *</Label>
                <Input type="date" value={form.expiry_date}
                  onChange={e => setForm({ ...form, expiry_date: e.target.value })} />
              </div>
            </div>
            <div className="space-y-2">
              <Label className="flex items-center gap-1.5"><Package className="w-3.5 h-3.5" />Medicamento *</Label>
              <Select value={form.product_id} onValueChange={v => setForm({ ...form, product_id: v })}>
                <SelectTrigger><SelectValue placeholder="Selecionar medicamento" /></SelectTrigger>
                <SelectContent>
                  {(products as any[]).map((p: any) => (
                    <SelectItem key={p.id} value={String(p.id)}>{p.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Quantidade</Label>
                <Input type="number" min="0" placeholder="0" value={form.quantity}
                  onChange={e => setForm({ ...form, quantity: e.target.value })} />
              </div>
              <div className="space-y-2">
                <Label className="flex items-center gap-1.5"><Building2 className="w-3.5 h-3.5" />Fornecedor</Label>
                <Select value={form.supplier_id} onValueChange={v => setForm({ ...form, supplier_id: v })}>
                  <SelectTrigger><SelectValue placeholder="Selecionar" /></SelectTrigger>
                  <SelectContent>
                    {(suppliers as any[]).map((s: any) => (
                      <SelectItem key={s.id} value={String(s.id)}>{s.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-2">
              <Label>Código de Barras</Label>
              <Input placeholder="Opcional" value={form.barcode}
                onChange={e => setForm({ ...form, barcode: e.target.value })} />
            </div>
            <DialogFooter className="gap-2 pt-2">
              <Button type="button" variant="outline" onClick={() => setIsOpen(false)}>Cancelar</Button>
              <Button type="submit" disabled={saveMutation.isPending}>
                {saveMutation.isPending ? <span className="flex items-center gap-2"><span className="btn-spinner" />A guardar...</span>
                  : (editItem ? "Actualizar" : "Cadastrar")}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <AlertDialog open={deleteId !== null} onOpenChange={open => !open && setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Eliminar Lote?</AlertDialogTitle>
            <AlertDialogDescription>Esta acção é irreversível.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={() => deleteId && deleteMutation.mutate(deleteId)}
              className="bg-destructive text-destructive-foreground">
              {deleteMutation.isPending ? <span className="flex items-center gap-2"><span className="btn-spinner" />A eliminar...</span> : "Eliminar"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
