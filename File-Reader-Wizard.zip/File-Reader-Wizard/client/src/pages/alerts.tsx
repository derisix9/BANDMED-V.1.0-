import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Bell, AlertTriangle, Info, CheckCircle, RefreshCw, Check, Clock, Package } from "lucide-react";
import { format } from "date-fns";
import { pt } from "date-fns/locale";

function AlertCard({ alert, onRead }: { alert: any; onRead: (id: number) => void }) {
  const isRead = alert.is_read;
  const icons: Record<string, any> = { critico: AlertTriangle, aviso: Clock, info: Info };
  const Icon = icons[alert.severity] || Info;
  const colors: Record<string, string> = {
    critico: "hsl(0, 72%, 51%)",
    aviso: "hsl(38, 92%, 45%)",
    info: "hsl(205, 75%, 40%)",
  };
  const bgClasses: Record<string, string> = {
    critico: "badge-critical",
    aviso: "badge-warning",
    info: "badge-info",
  };
  const color = colors[alert.severity] || colors.info;
  const bgCls = bgClasses[alert.severity] || bgClasses.info;

  return (
    <div className={`flex items-start gap-3 p-4 rounded-xl border transition-all ${isRead ? "opacity-60 bg-muted/20 border-border" : "bg-card border-border shadow-sm"}`}>
      <div className={`w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 ${bgCls}`}>
        <Icon className="w-4 h-4" />
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-start justify-between gap-2 flex-wrap">
          <div className="flex items-center gap-2 flex-wrap">
            <p className={`text-sm font-semibold ${isRead ? "text-muted-foreground" : "text-foreground"}`}>{alert.title}</p>
            {!isRead && (
              <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${bgCls}`}>
                {alert.severity === 'critico' ? 'Crítico' : alert.severity === 'aviso' ? 'Aviso' : 'Info'}
              </span>
            )}
          </div>
          <span className="text-xs text-muted-foreground flex-shrink-0">
            {format(new Date(alert.created_at), "dd/MM HH:mm", { locale: pt })}
          </span>
        </div>
        <p className="text-xs text-muted-foreground mt-1 leading-relaxed">{alert.message}</p>
        {alert.product_name && (
          <div className="flex items-center gap-1 mt-1.5">
            <Package className="w-3 h-3 text-muted-foreground" />
            <span className="text-xs text-muted-foreground">{alert.product_name}</span>
          </div>
        )}
      </div>
      {!isRead && (
        <Button size="icon" variant="ghost" className="w-7 h-7 flex-shrink-0" onClick={() => onRead(alert.id)}
          title="Marcar como lido">
          <Check className="w-3.5 h-3.5" />
        </Button>
      )}
    </div>
  );
}

export default function Alerts() {
  const { toast } = useToast();
  const { data: alerts = [], isLoading } = useQuery<any[]>({ queryKey: ["/api/alerts"] });

  const readMutation = useMutation({
    mutationFn: (id: number) => apiRequest("PUT", `/api/alerts/${id}/read`),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["/api/alerts"] }),
  });

  const readAllMutation = useMutation({
    mutationFn: () => apiRequest("PUT", "/api/alerts/read-all"),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/alerts"] });
      toast({ title: "Todos os alertas marcados como lidos" });
    },
  });

  const generateMutation = useMutation({
    mutationFn: () => apiRequest("POST", "/api/alerts/generate"),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/alerts"] });
      toast({ title: "Alertas actualizados" });
    },
  });

  const unread = (alerts as any[]).filter(a => !a.is_read);
  const criticos = unread.filter(a => a.severity === 'critico');
  const avisos = unread.filter(a => a.severity === 'aviso');
  const read = (alerts as any[]).filter(a => a.is_read);

  return (
    <div className="flex flex-col h-full overflow-y-auto">
      <div className="flex-shrink-0 px-6 py-4 border-b border-border bg-card/50">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <Bell className="w-5 h-5 text-primary" />
            <h1 className="text-xl font-bold">Alertas</h1>
            {unread.length > 0 && (
              <span className="badge-critical px-2 py-0.5 rounded-full text-xs font-bold">{unread.length}</span>
            )}
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            <Button variant="outline" size="sm" onClick={() => generateMutation.mutate()} className="gap-1.5"
              disabled={generateMutation.isPending}>
              {generateMutation.isPending ? <span className="btn-spinner" /> : <RefreshCw className="w-3.5 h-3.5" />}
              Actualizar
            </Button>
            {unread.length > 0 && (
              <Button variant="outline" size="sm" onClick={() => readAllMutation.mutate()} className="gap-1.5"
                disabled={readAllMutation.isPending}>
                {readAllMutation.isPending ? <span className="btn-spinner" /> : <CheckCircle className="w-3.5 h-3.5" />}
                Marcar todos lidos
              </Button>
            )}
          </div>
        </div>

        {/* Summary */}
        <div className="flex flex-wrap gap-3 mt-3">
          <div className="flex items-center gap-1.5 text-xs">
            <AlertTriangle className="w-3.5 h-3.5" style={{ color: "hsl(0, 72%, 51%)" }} />
            <span className="font-semibold">{criticos.length}</span>
            <span className="text-muted-foreground">crítico{criticos.length !== 1 ? "s" : ""}</span>
          </div>
          <div className="flex items-center gap-1.5 text-xs">
            <Clock className="w-3.5 h-3.5" style={{ color: "hsl(38, 92%, 45%)" }} />
            <span className="font-semibold">{avisos.length}</span>
            <span className="text-muted-foreground">aviso{avisos.length !== 1 ? "s" : ""}</span>
          </div>
          <div className="flex items-center gap-1.5 text-xs">
            <CheckCircle className="w-3.5 h-3.5 text-muted-foreground" />
            <span className="text-muted-foreground">{read.length} lido{read.length !== 1 ? "s" : ""}</span>
          </div>
        </div>
      </div>

      <div className="flex-1 p-6 space-y-6">
        {isLoading ? (
          <div className="flex items-center justify-center h-40">
            <div className="btn-spinner w-8 h-8 border-2 border-primary/30 border-t-primary" />
          </div>
        ) : (alerts as any[]).length === 0 ? (
          <Card>
            <CardContent className="flex flex-col items-center justify-center py-16 gap-3">
              <CheckCircle className="w-14 h-14 text-green-500/40" />
              <p className="font-semibold text-foreground">Tudo em ordem!</p>
              <p className="text-sm text-muted-foreground">Não há alertas activos no sistema.</p>
              <Button variant="outline" onClick={() => generateMutation.mutate()} className="gap-2 mt-2">
                <RefreshCw className="w-4 h-4" />Verificar novos alertas
              </Button>
            </CardContent>
          </Card>
        ) : (
          <>
            {unread.length > 0 && (
              <div className="space-y-3">
                <h2 className="text-sm font-semibold text-foreground flex items-center gap-2">
                  <Bell className="w-4 h-4 text-primary" />
                  Não lidos ({unread.length})
                </h2>
                {/* Críticos first */}
                {criticos.length > 0 && (
                  <div className="space-y-2">
                    <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide pl-1">Críticos</p>
                    {criticos.map((a: any) => (
                      <AlertCard key={a.id} alert={a} onRead={id => readMutation.mutate(id)} />
                    ))}
                  </div>
                )}
                {avisos.length > 0 && (
                  <div className="space-y-2">
                    <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide pl-1">Avisos</p>
                    {avisos.map((a: any) => (
                      <AlertCard key={a.id} alert={a} onRead={id => readMutation.mutate(id)} />
                    ))}
                  </div>
                )}
              </div>
            )}
            {read.length > 0 && (
              <div className="space-y-3">
                <h2 className="text-sm font-semibold text-muted-foreground flex items-center gap-2">
                  <CheckCircle className="w-4 h-4" />
                  Lidos ({read.length})
                </h2>
                <div className="space-y-2">
                  {read.map((a: any) => (
                    <AlertCard key={a.id} alert={a} onRead={id => readMutation.mutate(id)} />
                  ))}
                </div>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
