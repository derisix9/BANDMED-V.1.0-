import { useEffect, useState } from "react";
import { Activity, Shield, Package } from "lucide-react";
import splashLogo from "@assets/2d29899d85227a37d2321e36278d0eca_1772145177183.png";

interface SplashProps {
  onFinish: () => void;
}

export default function Splash({ onFinish }: SplashProps) {
  const [progress, setProgress] = useState(0);
  const [statusText, setStatusText] = useState("A inicializar sistema...");

  useEffect(() => {
    const steps = [
      { delay: 400, progress: 20, text: "A carregar base de dados..." },
      { delay: 900, progress: 45, text: "A verificar autenticação..." },
      { delay: 1400, progress: 70, text: "A carregar módulos..." },
      { delay: 1900, progress: 90, text: "A preparar interface..." },
      { delay: 2400, progress: 100, text: "Concluído!" },
    ];

    const timers: ReturnType<typeof setTimeout>[] = [];

    steps.forEach(({ delay, progress, text }) => {
      timers.push(setTimeout(() => {
        setProgress(progress);
        setStatusText(text);
      }, delay));
    });

    const finishTimer = setTimeout(onFinish, 2800);
    timers.push(finishTimer);

    return () => timers.forEach(clearTimeout);
  }, [onFinish]);

  return (
    <div className="fixed inset-0 flex flex-col items-center justify-center z-50 overflow-hidden"
      style={{ background: "linear-gradient(135deg, hsl(215, 42%, 14%) 0%, hsl(205, 60%, 22%) 50%, hsl(215, 42%, 10%) 100%)" }}>

      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {[...Array(6)].map((_, i) => (
          <div key={i} className="absolute rounded-full opacity-10"
            style={{
              width: `${100 + i * 80}px`, height: `${100 + i * 80}px`,
              border: "1px solid hsl(195, 75%, 50%)",
              top: "50%", left: "50%",
              transform: "translate(-50%, -50%)",
              animation: `pulse-ring ${1.5 + i * 0.3}s cubic-bezier(0.215, 0.61, 0.355, 1) infinite`,
              animationDelay: `${i * 0.2}s`,
            }}
          />
        ))}
      </div>

      <div className="relative z-10 flex flex-col items-center gap-8 px-8 max-w-sm w-full">
        <div className="relative">
          <div className="absolute inset-0 rounded-full opacity-30"
            style={{ background: "hsl(195, 75%, 50%)", filter: "blur(20px)", transform: "scale(1.5)" }} />
          <div className="relative w-28 h-28 rounded-full flex items-center justify-center overflow-hidden bg-white/10 backdrop-blur-sm">
            <div className="absolute inset-0 rounded-full border-4 border-transparent spin-slow"
              style={{ borderTopColor: "hsl(195, 75%, 70%)", borderRightColor: "hsl(195, 75%, 60%)" }} />
            <img src={splashLogo} alt="BANDMED Logo" className="w-20 h-20 object-contain relative z-10" />
          </div>
        </div>

        <div className="text-center splash-fade-in">
          <div className="flex items-center justify-center gap-2 mb-1">
            <Shield className="w-4 h-4" style={{ color: "hsl(195, 75%, 60%)" }} />
            <span className="text-xs font-semibold tracking-widest uppercase" style={{ color: "hsl(195, 75%, 60%)" }}>
              Sistema de Gestão
            </span>
          </div>
          <h1 className="text-3xl font-black text-white leading-tight tracking-tighter">
            BANDMED
          </h1>
          <p className="text-sm text-white/60 mt-1 font-medium tracking-wide uppercase">
            Gestão Hospitalar Inteligente
          </p>
        </div>

        <div className="w-full flex gap-2 items-center justify-center" style={{ animationDelay: "0.3s" }}>
          {[Activity, Package, Shield].map((Icon, i) => (
            <div key={i} className="p-2 rounded-lg" style={{ background: "rgba(255,255,255,0.08)" }}>
              <Icon className="w-4 h-4 text-white/50" />
            </div>
          ))}
        </div>

        <div className="w-full space-y-3">
          <div className="w-full h-1.5 rounded-full overflow-hidden" style={{ background: "rgba(255,255,255,0.1)" }}>
            <div className="h-full rounded-full transition-all duration-500 ease-out"
              style={{
                width: `${progress}%`,
                background: "linear-gradient(90deg, hsl(195, 75%, 45%), hsl(175, 65%, 40%))",
              }}
            />
          </div>

          <div className="flex justify-between items-center">
            <span className="text-xs text-white/50">{statusText}</span>
            <span className="text-xs font-mono" style={{ color: "hsl(195, 75%, 60%)" }}>{progress}%</span>
          </div>

          <div className="flex justify-center gap-2 mt-2">
            {[0, 1, 2].map((i) => (
              <div key={i} className={`w-2 h-2 rounded-full dot-${i + 1}`}
                style={{ background: "hsl(195, 75%, 55%)" }} />
            ))}
          </div>
        </div>

        <p className="text-xs text-white/30 text-center">
          v1.0.0 • Sistema Offline • © 2024
        </p>
      </div>
    </div>
  );
}
