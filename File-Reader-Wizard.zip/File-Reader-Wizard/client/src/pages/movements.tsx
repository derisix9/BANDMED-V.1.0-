import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Card, CardContent } from "@/components/ui/card";
import { ArrowLeftRight, Plus, Search, Edit, Trash2, TrendingUp, TrendingDown, Package, MapPin, Calendar, DollarSign, Hash } from "lucide-react";
import { format, parseISO } from "date-fns";

const emptyForm = { product_id: "", type: "entrada", quantity: "", destination: "", movement_date: new Date().toISOString().split('T')[0], price: "", lot_id: "", notes: "" };

export default function Movements() {
  const { toast } = useToast();
  const [search, setSearch] = useState("");
  const [typeFilter, setTypeFilter] = useState("all");
  const [isOpen, setIsOpen] = useState(false);
  const [editItem, setEditItem] = useState<any>(null);
  const [deleteId, setDeleteId] = useState<number | null>(null);
  const [form, setForm] = useState(emptyForm);

  const { data: movements = [], isLoading } = useQuery<any[]>({ queryKey: ["/api/movements"] });
  const { data: products = [] } = useQuery<any[]>({ queryKey: ["/api/products"] });
  const { data: lots = [] } = useQuery<any[]>({ queryKey: ["/api/lots"] });

  const availableLots = (lots as any[]).filter(l => !form.product_id || String(l.product_id) === form.product_id);

  const saveMutation = useMutation({
    mutationFn: async (data: any) => {
      if (editItem) return (await apiRequest("PUT", `/api/movements/${editItem.id}`, data)).json();
      const res = await apiRequest("POST", "/api/movements", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/movements"] });
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/recent-movements"] });
      queryClient.invalidateQueries({ queryKey: ["/api/alerts"] });
      toast({ title: editItem ? "Movimentação actualizada" : "Movimentação registada" });
      setIsOpen(false);
    },
    onError: (e: any) => toast({ title: "Erro", description: e.message, variant: "destructive" }),
  });

  const deleteMutation = useMutation({
    mutationFn: (id: number) => apiRequest("DELETE", `/api/movements/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/movements"] });
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      toast({ title: "Movimentação eliminada" });
      setDeleteId(null);
    },
    onError: (e: any) => toast({ title: "Erro", description: e.message, variant: "destructive" }),
  });

  const openCreate = () => { setEditItem(null); setForm(emptyForm); setIsOpen(true); };
  const openEdit = (item: any) => {
    setEditItem(item);
    setForm({
      product_id: item.product_id ? String(item.product_id) : "",
      type: item.type || "entrada",
      quantity: item.quantity != null ? String(item.quantity) : "",
      destination: item.destination || "",
      movement_date: item.movement_date || new Date().toISOString().split('T')[0],
      price: item.price != null ? String(item.price) : "",
      lot_id: item.lot_id ? String(item.lot_id) : "",
      notes: item.notes || "",
    });
    setIsOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.product_id || !form.type || !form.quantity) {
      toast({ title: "Produto, tipo e quantidade são obrigatórios", variant: "destructive" }); return;
    }
    saveMutation.mutate({
      product_id: Number(form.product_id),
      type: form.type,
      quantity: Number(form.quantity),
      destination: form.destination || null,
      movement_date: form.movement_date,
      price: form.price ? Number(form.price) : null,
      lot_id: (form.lot_id && form.lot_id !== "none") ? Number(form.lot_id) : null,
      notes: form.notes || null,
    });
  };

  const filtered = (movements as any[]).filter(m => {
    const matchSearch = m.product_name?.toLowerCase().includes(search.toLowerCase()) ||
      m.destination?.toLowerCase().includes(search.toLowerCase()) ||
      m.lot_number?.toLowerCase().includes(search.toLowerCase());
    const matchType = typeFilter === "all" || m.type === typeFilter;
    return matchSearch && matchType;
  });

  const totalEntries = filtered.filter(m => m.type === 'entrada').reduce((s, m) => s + m.quantity, 0);
  const totalExits = filtered.filter(m => m.type === 'saida').reduce((s, m) => s + m.quantity, 0);

  return (
    <div className="flex flex-col h-full overflow-y-auto">
      <div className="flex-shrink-0 px-6 py-4 border-b border-border bg-card/50">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <ArrowLeftRight className="w-5 h-5 text-primary" />
            <h1 className="text-xl font-bold">Entrada / Saída</h1>
            <span className="badge-info px-2 py-0.5 rounded-full text-xs font-medium">{filtered.length}</span>
          </div>
          <Button onClick={openCreate} className="gap-2" data-testid="button-add-movement">
            <Plus className="w-4 h-4" /> Nova Movimentação
          </Button>
        </div>
        <div className="mt-3 flex flex-wrap gap-3 items-center">
          <div className="relative flex-1 min-w-48 max-w-sm">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input placeholder="Pesquisar movimentações..." className="pl-9" value={search}
              onChange={e => setSearch(e.target.value)} />
          </div>
          <Select value={typeFilter} onValueChange={setTypeFilter}>
            <SelectTrigger className="w-40"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos os tipos</SelectItem>
              <SelectItem value="entrada">Entradas</SelectItem>
              <SelectItem value="saida">Saídas</SelectItem>
            </SelectContent>
          </Select>
          <div className="flex items-center gap-3 ml-auto">
            <span className="inline-flex items-center gap-1 text-xs font-medium" style={{ color: "hsl(142, 72%, 35%)" }}>
              <TrendingUp className="w-3.5 h-3.5" />{totalEntries} entradas
            </span>
            <span className="inline-flex items-center gap-1 text-xs font-medium" style={{ color: "hsl(0, 72%, 51%)" }}>
              <TrendingDown className="w-3.5 h-3.5" />{totalExits} saídas
            </span>
          </div>
        </div>
      </div>

      <div className="flex-1 p-6">
        {isLoading ? (
          <div className="flex items-center justify-center h-40">
            <div className="btn-spinner w-8 h-8 border-2 border-primary/30 border-t-primary" />
          </div>
        ) : filtered.length === 0 ? (
          <Card>
            <CardContent className="flex flex-col items-center justify-center py-12 gap-3">
              <ArrowLeftRight className="w-12 h-12 text-muted-foreground/30" />
              <p className="text-muted-foreground font-medium">Nenhuma movimentação encontrada</p>
              <Button onClick={openCreate} variant="outline" className="gap-2">
                <Plus className="w-4 h-4" /> Registar movimentação
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="rounded-lg border border-border overflow-hidden bg-card">
            <div className="overflow-x-auto">
              <table className="data-table">
                <thead className="bg-muted/50 border-b border-border">
                  <tr>
                    <th className="text-left data-table">Tipo</th>
                    <th className="text-left data-table">Medicamento</th>
                    <th className="text-center data-table">Quantidade</th>
                    <th className="text-left data-table hidden sm:table-cell">Destino</th>
                    <th className="text-left data-table hidden md:table-cell">Lote</th>
                    <th className="text-left data-table hidden lg:table-cell">Data</th>
                    <th className="text-left data-table hidden xl:table-cell">Preço</th>
                    <th className="text-center data-table">Ações</th>
                  </tr>
                </thead>
                <tbody>
                  {filtered.map((m: any) => (
                    <tr key={m.id} className="border-b border-border last:border-0 hover:bg-muted/30 transition-colors">
                      <td className="data-table">
                        <span className={`inline-flex items-center gap-1.5 text-xs px-2.5 py-1 rounded-full font-semibold ${m.type === 'entrada' ? 'badge-active' : 'badge-warning'}`}>
                          {m.type === 'entrada' ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
                          {m.type === 'entrada' ? 'Entrada' : 'Saída'}
                        </span>
                      </td>
                      <td className="data-table">
                        <div className="flex items-center gap-1.5 text-sm">
                          <Package className="w-3.5 h-3.5 text-muted-foreground flex-shrink-0" />
                          <span className="font-medium truncate max-w-40">{m.product_name}</span>
                        </div>
                      </td>
                      <td className="data-table text-center">
                        <span className="text-sm font-bold">{m.quantity}</span>
                        <span className="text-xs text-muted-foreground ml-1">un</span>
                      </td>
                      <td className="data-table hidden sm:table-cell">
                        <div className="flex items-center gap-1 text-sm text-muted-foreground">
                          <MapPin className="w-3 h-3 flex-shrink-0" />
                          <span className="truncate max-w-28">{m.destination || "—"}</span>
                        </div>
                      </td>
                      <td className="data-table hidden md:table-cell">
                        <div className="flex items-center gap-1 text-sm text-muted-foreground font-mono">
                          <Hash className="w-3 h-3 flex-shrink-0" />
                          {m.lot_number || "—"}
                        </div>
                      </td>
                      <td className="data-table hidden lg:table-cell">
                        <div className="flex items-center gap-1 text-sm text-muted-foreground">
                          <Calendar className="w-3 h-3 flex-shrink-0" />
                          {m.movement_date ? format(parseISO(m.movement_date), "dd/MM/yyyy") : "—"}
                        </div>
                      </td>
                      <td className="data-table hidden xl:table-cell">
                        <span className="text-sm text-muted-foreground">
                          {m.price != null ? `${Number(m.price).toLocaleString('pt-AO')} AOA` : "—"}
                        </span>
                      </td>
                      <td className="data-table text-center">
                        <div className="flex items-center justify-center gap-1">
                          <Button size="icon" variant="ghost" onClick={() => openEdit(m)} className="w-8 h-8">
                            <Edit className="w-3.5 h-3.5" />
                          </Button>
                          <Button size="icon" variant="ghost" onClick={() => setDeleteId(m.id)}
                            className="w-8 h-8 text-destructive hover:text-destructive">
                            <Trash2 className="w-3.5 h-3.5" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>

      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <ArrowLeftRight className="w-5 h-5 text-primary" />
              {editItem ? "Editar Movimentação" : "Nova Movimentação"}
            </DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4 py-2">
            <div className="space-y-2">
              <Label className="flex items-center gap-1.5"><Package className="w-3.5 h-3.5" />Medicamento *</Label>
              <Select value={form.product_id} onValueChange={v => setForm({ ...form, product_id: v, lot_id: "" })}>
                <SelectTrigger><SelectValue placeholder="Selecionar medicamento" /></SelectTrigger>
                <SelectContent>
                  {(products as any[]).map((p: any) => (
                    <SelectItem key={p.id} value={String(p.id)}>
                      {p.name} {p.current_stock != null ? `(Stock: ${p.current_stock})` : ""}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Tipo *</Label>
                <Select value={form.type} onValueChange={v => setForm({ ...form, type: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="entrada">
                      <span className="flex items-center gap-2"><TrendingUp className="w-3.5 h-3.5" />Entrada</span>
                    </SelectItem>
                    <SelectItem value="saida">
                      <span className="flex items-center gap-2"><TrendingDown className="w-3.5 h-3.5" />Saída</span>
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Quantidade *</Label>
                <Input type="number" min="1" placeholder="0" value={form.quantity}
                  onChange={e => setForm({ ...form, quantity: e.target.value })} />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="flex items-center gap-1.5"><Calendar className="w-3.5 h-3.5" />Data</Label>
                <Input type="date" value={form.movement_date}
                  onChange={e => setForm({ ...form, movement_date: e.target.value })} />
              </div>
              <div className="space-y-2">
                <Label className="flex items-center gap-1.5"><DollarSign className="w-3.5 h-3.5" />Preço (AOA)</Label>
                <Input type="number" min="0" step="0.01" placeholder="0.00" value={form.price}
                  onChange={e => setForm({ ...form, price: e.target.value })} />
              </div>
            </div>
            <div className="space-y-2">
              <Label className="flex items-center gap-1.5"><MapPin className="w-3.5 h-3.5" />Destino / Origem</Label>
              <Input placeholder="Ex: Enfermaria A, Pediatria..." value={form.destination}
                onChange={e => setForm({ ...form, destination: e.target.value })} />
            </div>
            <div className="space-y-2">
              <Label className="flex items-center gap-1.5"><Hash className="w-3.5 h-3.5" />Lote</Label>
              <Select value={form.lot_id} onValueChange={v => setForm({ ...form, lot_id: v })}>
                <SelectTrigger><SelectValue placeholder="Selecionar lote (opcional)" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">Sem lote específico (FIFO automático)</SelectItem>
                  {availableLots.map((l: any) => (
                    <SelectItem key={l.id} value={String(l.id)}>
                      {l.lot_number} • Val: {l.expiry_date} • Qty: {l.quantity}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Observações</Label>
              <Input placeholder="Notas adicionais (opcional)" value={form.notes}
                onChange={e => setForm({ ...form, notes: e.target.value })} />
            </div>
            {form.type === 'saida' && (
              <div className="p-3 rounded-lg bg-muted/50 border border-border text-xs text-muted-foreground">
                <strong>Nota:</strong> Para saídas, o sistema selecciona automaticamente o lote com validade mais próxima (FIFO). O stock mínimo será verificado antes de confirmar.
              </div>
            )}
            <DialogFooter className="gap-2 pt-2">
              <Button type="button" variant="outline" onClick={() => setIsOpen(false)}>Cancelar</Button>
              <Button type="submit" disabled={saveMutation.isPending}>
                {saveMutation.isPending ? <span className="flex items-center gap-2"><span className="btn-spinner" />A registar...</span>
                  : (editItem ? "Actualizar" : "Registar")}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <AlertDialog open={deleteId !== null} onOpenChange={open => !open && setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Eliminar Movimentação?</AlertDialogTitle>
            <AlertDialogDescription>Esta acção afectará o stock do produto associado.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={() => deleteId && deleteMutation.mutate(deleteId)}
              className="bg-destructive text-destructive-foreground">
              {deleteMutation.isPending ? <span className="flex items-center gap-2"><span className="btn-spinner" />A eliminar...</span> : "Eliminar"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
