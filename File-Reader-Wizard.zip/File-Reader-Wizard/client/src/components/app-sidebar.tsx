import { Link, useLocation } from "wouter";
import {
  Sidebar, SidebarContent, SidebarGroup, SidebarGroupContent, SidebarGroupLabel,
  SidebarMenu, SidebarMenuButton, SidebarMenuItem, SidebarHeader, SidebarFooter,
} from "@/components/ui/sidebar";
import {
  LayoutDashboard, Package, Building2, Archive, Layers,
  ArrowLeftRight, Bell, FileText, Database, LogOut, User,
  ChevronRight
} from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import sidebarLogo from "@assets/2d29899d85227a37d2321e36278d0eca_1772145177183.png";

const navGroups = [
  {
    label: "Principal",
    items: [
      { title: "Dashboard", url: "/", icon: LayoutDashboard },
      { title: "Medicamentos", url: "/products", icon: Package },
      { title: "Fornecedores", url: "/suppliers", icon: Building2 },
      { title: "Prateleiras", url: "/shelves", icon: Archive },
    ],
  },
  {
    label: "Movimentações",
    items: [
      { title: "Lotes", url: "/lots", icon: Layers },
      { title: "Entrada / Saída", url: "/movements", icon: ArrowLeftRight },
    ],
  },
  {
    label: "Sistema",
    items: [
      { title: "Alertas", url: "/alerts", icon: Bell },
      { title: "Relatórios", url: "/reports", icon: FileText },
      { title: "Base de Dados", url: "/database", icon: Database },
    ],
  },
];

export function AppSidebar() {
  const [location] = useLocation();
  const { user, logout } = useAuth();
  const { toast } = useToast();

  const { data: alerts } = useQuery<any[]>({ queryKey: ["/api/alerts"] });
  const unreadAlerts = alerts?.filter((a: any) => !a.is_read).length || 0;

  const handleLogout = async () => {
    try {
      await logout();
    } catch {
      toast({ title: "Erro ao sair", variant: "destructive" });
    }
  };

  const isActive = (url: string) => url === "/" ? location === "/" : location.startsWith(url);

  return (
    <Sidebar className="border-r-0">
      <SidebarHeader className="p-4 border-b border-sidebar-border">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 bg-white/5 overflow-hidden">
            <img src={sidebarLogo} alt="Logo" className="w-7 h-7 object-contain" />
          </div>
          <div className="min-w-0">
            <p className="text-sm font-black text-sidebar-foreground leading-tight tracking-tighter">
              BANDMED
            </p>
            <p className="text-[10px] font-medium leading-tight uppercase opacity-50">
              Gestão Hospitalar
            </p>
          </div>
        </div>
      </SidebarHeader>

      <SidebarContent className="py-2">
        {navGroups.map((group) => (
          <SidebarGroup key={group.label} className="px-2 py-1">
            <SidebarGroupLabel className="text-xs font-semibold tracking-widest uppercase text-sidebar-foreground/40 px-2 mb-1">
              {group.label}
            </SidebarGroupLabel>
            <SidebarGroupContent>
              <SidebarMenu>
                {group.items.map((item) => {
                  const active = isActive(item.url);
                  return (
                    <SidebarMenuItem key={item.title}>
                      <SidebarMenuButton asChild data-active={active}>
                        <Link href={item.url}
                          className={`flex items-center gap-3 px-3 py-2 rounded-lg transition-all duration-150 relative
                            ${active
                              ? "text-sidebar-primary-foreground font-medium"
                              : "text-sidebar-foreground/70 hover:text-sidebar-foreground"
                            }`}
                          style={active ? {
                            background: "linear-gradient(135deg, hsl(195, 75%, 38%), hsl(175, 65%, 30%))"
                          } : {}}>
                          <item.icon className="w-4 h-4 flex-shrink-0" />
                          <span className="flex-1 text-sm">{item.title}</span>
                          {item.url === "/alerts" && unreadAlerts > 0 && (
                            <span className="flex-shrink-0 min-w-5 h-5 rounded-full text-xs font-bold flex items-center justify-center px-1"
                              style={{ background: "hsl(0, 72%, 51%)", color: "white" }}>
                              {unreadAlerts > 99 ? "99+" : unreadAlerts}
                            </span>
                          )}
                          {active && <ChevronRight className="w-3 h-3 flex-shrink-0 opacity-70" />}
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  );
                })}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        ))}
      </SidebarContent>

      <SidebarFooter className="p-3 border-t border-sidebar-border">
        <div className="flex items-center gap-3 px-2 py-2 rounded-lg mb-2"
          style={{ background: "rgba(255,255,255,0.05)" }}>
          <div className="w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0"
            style={{ background: "linear-gradient(135deg, hsl(195, 75%, 38%), hsl(175, 65%, 32%))" }}>
            <User className="w-4 h-4 text-white" />
          </div>
          <div className="min-w-0 flex-1">
            <p className="text-sm font-medium text-sidebar-foreground truncate">{user?.name}</p>
            <p className="text-xs text-sidebar-foreground/50 truncate">{user?.role}</p>
          </div>
        </div>
        <Button variant="ghost" className="w-full justify-start gap-2 text-sidebar-foreground/60 hover:text-sidebar-foreground text-sm h-9"
          onClick={handleLogout} data-testid="button-logout">
          <LogOut className="w-4 h-4" />
          Terminar Sessão
        </Button>
      </SidebarFooter>
    </Sidebar>
  );
}
